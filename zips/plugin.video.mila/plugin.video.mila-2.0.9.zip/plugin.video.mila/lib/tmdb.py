# -*- coding: utf-8 -*-
# TMDB API wrapper - WITH ALL DISCOVER METHODS AND BASIC LISTS FIXED
import requests
import time
import hashlib
import json
import xbmc
from datetime import datetime, timedelta
from lib.utils import log, cache_get, cache_set

class TMDB:
    def __init__(self, addon):
        self.api_key = addon.getSetting('tmdb_api_key') or "9567cc1179d493c3b22f0682dbdf2e42"
        self.addon = addon
        self.base_url = "https://api.themoviedb.org/3"
        self.image_url = "https://image.tmdb.org/t/p/"

        # Get language from settings
        self.language = addon.getSetting('tmdb_language')
        if not self.language or self.language == '':
            self.language = 'en-US'

        log(f"🎯 TMDB using language: {self.language}")

        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })

    def _get(self, endpoint, params=None, language_override=None):
        """Make TMDB API request with caching and PROPER LANGUAGE HANDLING"""
        if params is None:
            params = {}

        lang = language_override if language_override else self.language
        params['language'] = lang
        params['api_key'] = self.api_key
        params['include_image_language'] = f"{lang.split('-')[0]},en,null"

        param_str = json.dumps(params, sort_keys=True)
        cache_key = f"tmdb_{endpoint}_{hashlib.md5(param_str.encode()).hexdigest()}"

        cached = cache_get(cache_key, ttl=86400)
        if cached:
            log(f"📦 Cache hit: {endpoint} ({lang})")
            return cached

        try:
            url = f"{self.base_url}/{endpoint}"
            log(f"🌐 TMDB request: {url} | language={lang}")

            response = self.session.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                cache_set(cache_key, data)
                return data
            elif response.status_code == 429:
                log(f"⏳ TMDB rate limit hit, waiting...")
                time.sleep(2)
                return self._get(endpoint, params, language_override)
            else:
                log(f"❌ TMDB error {response.status_code}: {endpoint}")

        except Exception as e:
            log(f"❌ TMDB exception: {str(e)}")

        return None

    # ===== MOVIE DETAILS =====

    def get_movie_details(self, tmdb_id):
        """Get movie details with credits - IN USER'S LANGUAGE"""
        return self._get(f"movie/{tmdb_id}", {
            'append_to_response': 'credits,release_dates,videos,translations,keywords'
        })

    def search_movie(self, query):
        """Search for movies - RESULTS IN USER'S LANGUAGE"""
        log(f"🔍 Searching movies: {query} in {self.language}")
        data = self._get("search/movie", {
            'query': query,
            'include_adult': False
        })
        if data and 'results' in data:
            log(f"📊 Found {len(data['results'])} movie results")
            return data['results']
        return []

    # ===== TV DETAILS =====

    def get_tv_details(self, tmdb_id):
        """Get TV show details - IN USER'S LANGUAGE"""
        return self._get(f"tv/{tmdb_id}", {
            'append_to_response': 'credits,content_ratings,translations,keywords'
        })

    def get_tv_season(self, tmdb_id, season_num):
        """Get TV season details - IN USER'S LANGUAGE"""
        return self._get(f"tv/{tmdb_id}/season/{season_num}")

    def get_episode_details(self, tmdb_id, season_num, episode_num):
        """Get TV episode details - IN USER'S LANGUAGE"""
        return self._get(f"tv/{tmdb_id}/season/{season_num}/episode/{episode_num}")

    def search_tv(self, query):
        """Search for TV shows - RESULTS IN USER'S LANGUAGE"""
        log(f"🔍 Searching TV: {query} in {self.language}")
        data = self._get("search/tv", {
            'query': query,
            'include_adult': False
        })
        if data and 'results' in data:
            log(f"📊 Found {len(data['results'])} TV results")
            return data['results']
        return []

    # ===== BASIC LISTS - THESE WERE MISSING! =====
    
    def get_popular_movies(self):
        """Get popular movies"""
        data = self._get("movie/popular")
        return data.get('results', []) if data else []

    def get_top_rated_movies(self):
        """Get top rated movies"""
        data = self._get("movie/top_rated")
        return data.get('results', []) if data else []

    def get_popular_tv(self):
        """Get popular TV shows - THIS WAS MISSING!"""
        data = self._get("tv/popular")
        return data.get('results', []) if data else []

    def get_top_rated_tv(self):
        """Get top rated TV shows - THIS WAS MISSING!"""
        data = self._get("tv/top_rated")
        return data.get('results', []) if data else []

    def get_now_playing(self):
        """Now playing in theaters"""
        data = self._get("movie/now_playing")
        return data.get('results', []) if data else []

    def get_upcoming(self):
        """Upcoming movies"""
        data = self._get("movie/upcoming")
        return data.get('results', []) if data else []

    def get_list(self, list_type):
        """Get TMDB list by type - BACKWARD COMPATIBILITY"""
        if list_type == 'popular_movies':
            return self.get_popular_movies()
        elif list_type == 'top_rated_movies':
            return self.get_top_rated_movies()
        elif list_type == 'popular_tv':
            return self.get_popular_tv()
        elif list_type == 'top_rated_tv':
            return self.get_top_rated_tv()
        return []

    # ===== DISCOVER - ALL METHODS YOUR ADDON.PY CALLS =====

    def trending_week(self):
        """Trending this week"""
        data = self._get("trending/movie/week")
        return data.get('results', []) if data else []

    def trending_day(self):
        """Trending today"""
        data = self._get("trending/movie/day")
        return data.get('results', []) if data else []

    def now_playing(self):
        """Now playing"""
        data = self._get("movie/now_playing")
        return data.get('results', []) if data else []

    def upcoming(self):
        """Upcoming movies"""
        data = self._get("movie/upcoming")
        return data.get('results', []) if data else []

    # ===== GENRES =====
    def action_movies(self):
        data = self._get("discover/movie", {'with_genres': '28', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def adventure_movies(self):
        data = self._get("discover/movie", {'with_genres': '12', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def action_adventure(self):
        data = self._get("discover/movie", {'with_genres': '28,12', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def comedy_movies(self):
        data = self._get("discover/movie", {'with_genres': '35', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def drama_movies(self):
        data = self._get("discover/movie", {'with_genres': '18', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def comedy_drama(self):
        data = self._get("discover/movie", {'with_genres': '35,18', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def thriller_movies(self):
        data = self._get("discover/movie", {'with_genres': '53', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def horror_movies(self):
        data = self._get("discover/movie", {'with_genres': '27', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def thriller_horror(self):
        data = self._get("discover/movie", {'with_genres': '53,27', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def sci_fi_movies(self):
        data = self._get("discover/movie", {'with_genres': '878', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def fantasy_movies(self):
        data = self._get("discover/movie", {'with_genres': '14', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def sci_fi_fantasy(self):
        data = self._get("discover/movie", {'with_genres': '878,14', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def romance_movies(self):
        data = self._get("discover/movie", {'with_genres': '10749', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def family_movies(self):
        data = self._get("discover/movie", {'with_genres': '10751', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def animation_movies(self):
        data = self._get("discover/movie", {'with_genres': '16', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def family_animation(self):
        data = self._get("discover/movie", {'with_genres': '10751,16', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def documentary_movies(self):
        data = self._get("discover/movie", {'with_genres': '99', 'sort_by': 'popularity.desc', 'vote_count.gte': 50})
        return data.get('results', []) if data else []

    def war_movies(self):
        data = self._get("discover/movie", {'with_genres': '10752', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def history_movies(self):
        data = self._get("discover/movie", {'with_genres': '36', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def war_history(self):
        data = self._get("discover/movie", {'with_genres': '10752,36', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def crime_movies(self):
        data = self._get("discover/movie", {'with_genres': '80', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    def mystery_movies(self):
        data = self._get("discover/movie", {'with_genres': '9648', 'sort_by': 'popularity.desc', 'vote_count.gte': 100})
        return data.get('results', []) if data else []

    # ===== CZECH & REGIONAL =====
    def czech_movies(self):
        """Czech movies"""
        data = self._get("discover/movie", {
            'with_original_language': 'cs',
            'sort_by': 'popularity.desc',
            'vote_count.gte': 10
        })
        return data.get('results', []) if data else []

    def czech_recent(self):
        """Recent Czech movies"""
        current_year = datetime.now().year
        data = self._get("discover/movie", {
            'with_original_language': 'cs',
            'primary_release_date.gte': f"{current_year-5}-01-01",
            'sort_by': 'release_date.desc',
            'vote_count.gte': 5
        })
        return data.get('results', []) if data else []

    def czechoslovak_classics(self):
        """Czechoslovak classics"""
        data = self._get("discover/movie", {
            'with_original_language': 'cs',
            'primary_release_date.lte': '1992-12-31',
            'sort_by': 'vote_average.desc',
            'vote_count.gte': 20
        })
        return data.get('results', []) if data else []

    def slovak_movies(self):
        """Slovak movies"""
        data = self._get("discover/movie", {
            'with_original_language': 'sk',
            'sort_by': 'popularity.desc'
        })
        return data.get('results', []) if data else []

    # ===== STUDIOS =====
    def marvel_movies(self):
        data = self._get("discover/movie", {'with_companies': '420', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def dc_movies(self):
        data = self._get("discover/movie", {'with_companies': '429,174', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def disney_movies(self):
        data = self._get("discover/movie", {'with_companies': '2', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def netflix_movies(self):
        data = self._get("discover/movie", {'with_companies': '213850', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def hbo_movies(self):
        data = self._get("discover/movie", {'with_companies': '174,3186,19507', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def amazon_movies(self):
        data = self._get("discover/movie", {'with_companies': '102395,102396', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def apple_movies(self):
        data = self._get("discover/movie", {'with_companies': '175525', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def paramount_movies(self):
        data = self._get("discover/movie", {'with_companies': '4', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def universal_movies(self):
        data = self._get("discover/movie", {'with_companies': '33', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def warner_movies(self):
        data = self._get("discover/movie", {'with_companies': '174', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    def sony_movies(self):
        data = self._get("discover/movie", {'with_companies': '34', 'sort_by': 'release_date.desc'})
        return data.get('results', []) if data else []

    # ===== DECADES =====
    def _80s_movies(self):
        data = self._get("discover/movie", {
            'primary_release_date.gte': '1980-01-01',
            'primary_release_date.lte': '1989-12-31',
            'sort_by': 'popularity.desc',
            'vote_count.gte': 100
        })
        return data.get('results', []) if data else []

    def _90s_movies(self):
        data = self._get("discover/movie", {
            'primary_release_date.gte': '1990-01-01',
            'primary_release_date.lte': '1999-12-31',
            'sort_by': 'popularity.desc',
            'vote_count.gte': 100
        })
        return data.get('results', []) if data else []

    def _00s_movies(self):
        data = self._get("discover/movie", {
            'primary_release_date.gte': '2000-01-01',
            'primary_release_date.lte': '2009-12-31',
            'sort_by': 'popularity.desc',
            'vote_count.gte': 100
        })
        return data.get('results', []) if data else []

    def _2010s_movies(self):
        data = self._get("discover/movie", {
            'primary_release_date.gte': '2010-01-01',
            'primary_release_date.lte': '2019-12-31',
            'sort_by': 'popularity.desc',
            'vote_count.gte': 100
        })
        return data.get('results', []) if data else []

    def _2020s_movies(self):
        data = self._get("discover/movie", {
            'primary_release_date.gte': '2020-01-01',
            'sort_by': 'popularity.desc',
            'vote_count.gte': 50
        })
        return data.get('results', []) if data else []

    # ===== SMART MIXES =====
    def cult_classics(self):
        data = self._get("discover/movie", {
            'with_keywords': '972',
            'sort_by': 'popularity.desc',
            'vote_count.gte': 50
        })
        return data.get('results', []) if data else []

    def feel_good_movies(self):
        data = self._get("discover/movie", {
            'with_genres': '35,10751,18',
            'without_genres': '53,27,80',
            'vote_average.gte': 6.5,
            'sort_by': 'popularity.desc',
            'vote_count.gte': 100
        })
        return data.get('results', []) if data else []

    def date_night_movies(self):
        data = self._get("discover/movie", {
            'with_genres': '10749,35,18',
            'vote_average.gte': 6.0,
            'sort_by': 'popularity.desc',
            'vote_count.gte': 100
        })
        return data.get('results', []) if data else []

    def weekend_binge(self):
        data = self._get("discover/movie", {
            'with_genres': '28,12,878,53',
            'vote_average.gte': 6.5,
            'sort_by': 'popularity.desc',
            'vote_count.gte': 100
        })
        return data.get('results', []) if data else []

    # ===== RECENT =====
    def this_month(self):
        thirty_days_ago = (datetime.now() - timedelta(days=30)).strftime('%Y-%m-%d')
        data = self._get("discover/movie", {
            'primary_release_date.gte': thirty_days_ago,
            'sort_by': 'popularity.desc',
            'vote_count.gte': 10
        })
        return data.get('results', []) if data else []

    def last_3_months(self):
        ninety_days_ago = (datetime.now() - timedelta(days=90)).strftime('%Y-%m-%d')
        data = self._get("discover/movie", {
            'primary_release_date.gte': ninety_days_ago,
            'sort_by': 'popularity.desc',
            'vote_count.gte': 20
        })
        return data.get('results', []) if data else []

    def this_year(self):
        current_year = datetime.now().year
        data = self._get("discover/movie", {
            'primary_release_date.gte': f"{current_year}-01-01",
            'sort_by': 'popularity.desc',
            'vote_count.gte': 20
        })
        return data.get('results', []) if data else []

    # ===== IMAGE HELPERS =====
    def get_image_url(self, path, size='original'):
        if not path:
            return ''
        return f"{self.image_url}{size}{path}"

    def get_poster(self, path, size='w500'):
        return self.get_image_url(path, size)

    def get_backdrop(self, path, size='original'):
        return self.get_image_url(path, size)

    def get_still(self, path, size='w500'):
        return self.get_image_url(path, size)

    # ===== LOCALIZED TITLES =====
    def get_movie_localized_titles(self, tmdb_id):
        """Get movie titles in Czech, Croatian, Serbian"""
        titles = {
            'english': None,
            'czech': None,
            'croatian': None,
            'serbian': None,
            'original': None
        }

        try:
            en_data = self._get(f"movie/{tmdb_id}", {'language': 'en-US'})
            if en_data:
                titles['english'] = en_data.get('title')
                titles['original'] = en_data.get('original_title')

            cz_data = self._get(f"movie/{tmdb_id}", {'language': 'cs-CZ'})
            if cz_data and cz_data.get('title'):
                cz_title = cz_data.get('title')
                if cz_title != titles['english']:
                    titles['czech'] = cz_title

            hr_data = self._get(f"movie/{tmdb_id}", {'language': 'hr-HR'})
            if hr_data and hr_data.get('title'):
                hr_title = hr_data.get('title')
                if hr_title != titles['english']:
                    titles['croatian'] = hr_title

            sr_data = self._get(f"movie/{tmdb_id}", {'language': 'sr-RS'})
            if sr_data and sr_data.get('title'):
                sr_title = sr_data.get('title')
                if sr_title != titles['english']:
                    titles['serbian'] = sr_title

            if not titles['czech']:
                titles['czech'] = titles['english']
            if not titles['croatian']:
                titles['croatian'] = titles['english']
            if not titles['serbian']:
                titles['serbian'] = titles['english']

        except Exception as e:
            log(f"Error getting localized titles: {str(e)}")
            titles['czech'] = titles.get('english', '')
            titles['croatian'] = titles.get('english', '')
            titles['serbian'] = titles.get('english', '')

        return titles

    def get_tv_localized_titles(self, tmdb_id):
        """Get TV show titles in Czech, Croatian, Serbian"""
        titles = {
            'english': None,
            'czech': None,
            'croatian': None,
            'serbian': None,
            'original': None
        }

        try:
            en_data = self._get(f"tv/{tmdb_id}", {'language': 'en-US'})
            if en_data:
                titles['english'] = en_data.get('name')
                titles['original'] = en_data.get('original_name')

            cz_data = self._get(f"tv/{tmdb_id}", {'language': 'cs-CZ'})
            if cz_data and cz_data.get('name'):
                cz_title = cz_data.get('name')
                if cz_title != titles['english']:
                    titles['czech'] = cz_title

            hr_data = self._get(f"tv/{tmdb_id}", {'language': 'hr-HR'})
            if hr_data and hr_data.get('name'):
                hr_title = hr_data.get('name')
                if hr_title != titles['english']:
                    titles['croatian'] = hr_title

            sr_data = self._get(f"tv/{tmdb_id}", {'language': 'sr-RS'})
            if sr_data and sr_data.get('name'):
                sr_title = sr_data.get('name')
                if sr_title != titles['english']:
                    titles['serbian'] = sr_title

            if not titles['czech']:
                titles['czech'] = titles['english']
            if not titles['croatian']:
                titles['croatian'] = titles['english']
            if not titles['serbian']:
                titles['serbian'] = titles['english']

        except Exception as e:
            log(f"Error getting localized titles: {str(e)}")
            titles['czech'] = titles.get('english', '')
            titles['croatian'] = titles.get('english', '')
            titles['serbian'] = titles.get('english', '')

        return titles

    def get_title_in_current_language(self, tmdb_id, media_type='movie'):
        """Get title in user's current language setting"""
        try:
            if media_type == 'movie':
                data = self._get(f"movie/{tmdb_id}")
                if data:
                    return data.get('title')
            else:
                data = self._get(f"tv/{tmdb_id}")
                if data:
                    return data.get('name')
        except Exception as e:
            log(f"Error getting title in current language: {str(e)}")
        return None
