# -*- coding: utf-8 -*-
# Kodi list item builders with multi-language support
import xbmc
import xbmcgui
import xbmcplugin
from lib.utils import log

class GUI:
    def __init__(self, addon_instance):
        self.addon = addon_instance
        self.handle = addon_instance.handle
        self.tmdb = addon_instance.tmdb
        self._strings = self._load_strings()

    def _get_kodi_language(self):
        """Get current Kodi interface language"""
        try:
            language = xbmc.getLanguage(xbmc.ISO_639_1).lower()
            return language
        except:
            return 'en'

    def _load_strings(self):
        """Load strings based on Kodi language"""
        lang = self._get_kodi_language()

        # Default English strings
        strings = {
            'select_stream': 'Select Stream',
            'season': 'Season',
            'episodes': 'episodes',
            'episode': 'Episode',
            'search_results': 'Found {} results',
            'no_files_found': 'No files found',
            'searching': 'Searching...',
            'popular_movies': 'Popular Movies',
            'top_rated_movies': 'Top Rated Movies',
            'popular_tv': 'Popular TV Shows',
            'top_rated_tv': 'Top Rated TV Shows',
            'search': 'Search',
            'movies': 'Movies',
            'tv_shows': 'TV Shows',
            'settings': 'Settings',
            'clear_cache': 'Clear Cache',
            'refresh': 'Refresh',
            
            # HISTORY STRINGS
            'search_history': 'Search History',
            'watch_history': 'Watch History',
            'no_search_history': 'No search history',
            'no_watch_history': 'No watch history',
            'remove_from_history': 'Remove from history',
            'clear_all': 'Clear all',
        }

        # Czech translations
        if lang in ['cs', 'cze', 'czech']:
            strings.update({
                'select_stream': 'Vybrat stream',
                'season': 'Sezóna',
                'episodes': 'epizod',
                'episode': 'Epizoda',
                'search_results': 'Nalezeno {} výsledků',
                'no_files_found': 'Nebyly nalezeny žádné soubory',
                'searching': 'Vyhledávání...',
                'popular_movies': 'Populární filmy',
                'top_rated_movies': 'Nejlépe hodnocené filmy',
                'popular_tv': 'Populární seriály',
                'top_rated_tv': 'Nejlépe hodnocené seriály',
                'search': 'Hledat',
                'movies': 'Filmy',
                'tv_shows': 'Seriály',
                'settings': 'Nastavení',
                'clear_cache': 'Vymazat cache',
                'refresh': 'Obnovit',
                
                # HISTORY STRINGS - CZECH
                'search_history': 'Historie vyhledávání',
                'watch_history': 'Historie sledování',
                'no_search_history': 'Žádná historie vyhledávání',
                'no_watch_history': 'Žádná historie sledování',
                'remove_from_history': 'Odstranit z historie',
                'clear_all': 'Vymazat vše',
            })

        # Croatian translations
        elif lang in ['hr', 'cro', 'croatian']:
            strings.update({
                'select_stream': 'Odaberi stream',
                'season': 'Sezona',
                'episodes': 'epizoda',
                'episode': 'Epizoda',
                'search_results': 'Pronađeno {} rezultata',
                'no_files_found': 'Nema pronađenih datoteka',
                'searching': 'Pretraživanje...',
                'popular_movies': 'Popularni filmovi',
                'top_rated_movies': 'Najbolje ocijenjeni filmovi',
                'popular_tv': 'Popularne serije',
                'top_rated_tv': 'Najbolje ocijenjene serije',
                'search': 'Traži',
                'movies': 'Filmovi',
                'tv_shows': 'Serije',
                'settings': 'Postavke',
                'clear_cache': 'Očisti predmemoriju',
                'refresh': 'Osvježi',
                
                # HISTORY STRINGS - CROATIAN
                'search_history': 'Povijest pretraživanja',
                'watch_history': 'Povijest gledanja',
                'no_search_history': 'Nema povijesti pretraživanja',
                'no_watch_history': 'Nema povijesti gledanja',
                'remove_from_history': 'Ukloni iz povijesti',
                'clear_all': 'Očisti sve',
            })

        return strings

    def _get_string(self, key, *args):
        """Get translated string with optional formatting"""
        string = self._strings.get(key, key)
        if args:
            try:
                return string.format(*args)
            except:
                return string
        return string

    def add_item(self, label, url, is_folder=True, art=None, info=None, cast=None, context_menu=None):
        """Generic method to add a directory item"""
        li = xbmcgui.ListItem(label=label)

        if art:
            li.setArt(art)

        if info:
            li.setInfo('video', info)

        if cast:
            li.setCast(cast)

        if context_menu:
            li.addContextMenuItems(context_menu)

        if not is_folder:
            li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(self.handle, url, li, is_folder)
        return li

    def add_movie_item(self, movie, is_search_result=False):
        """Add a movie item to the directory"""
        tmdb_id = movie.get('id')
        title = movie.get('title', 'Unknown')
        year = movie.get('release_date', '')[:4] if movie.get('release_date') else ''

        # Get full details for metadata
        details = self.tmdb.get_movie_details(tmdb_id) if tmdb_id else None

        # Build label
        label = f"[B]{title}[/B]"
        if year:
            label += f" ({year})"
        if details and details.get('vote_average'):
            rating = details['vote_average']
            label += f" [COLOR yellow]{rating:.1f}★[/COLOR]"

        # Build artwork
        art = {}
        if details:
            if details.get('poster_path'):
                art['poster'] = self.tmdb.get_poster(details['poster_path'], 'w500')
                art['thumb'] = self.tmdb.get_poster(details['poster_path'], 'w342')
            if details.get('backdrop_path'):
                art['fanart'] = self.tmdb.get_backdrop(details['backdrop_path'])

        if not art.get('poster'):
            art['poster'] = 'DefaultMovies.png'
            art['thumb'] = 'DefaultMovies.png'

        # Build info
        info = {'title': title, 'mediatype': 'movie'}
        if year:
            info['year'] = int(year) if year.isdigit() else 0
            info['premiered'] = movie.get('release_date', '')
        if details:
            info['plot'] = details.get('overview', '')
            info['rating'] = float(details.get('vote_average', 0))
            info['votes'] = str(details.get('vote_count', 0))

            # Genres
            genres = [g['name'] for g in details.get('genres', [])]
            if genres:
                info['genre'] = ' / '.join(genres)

            # Director
            if details.get('credits'):
                directors = [c['name'] for c in details['credits'].get('crew', [])
                           if c.get('job') == 'Director']
                if directors:
                    info['director'] = ' / '.join(directors)

        # Build cast
        cast = []
        if details and details.get('credits'):
            for person in details['credits'].get('cast', [])[:10]:
                cast.append({
                    'name': person.get('name', ''),
                    'role': person.get('character', ''),
                    'thumbnail': self.tmdb.get_image_url(person.get('profile_path'), 'w185')
                                if person.get('profile_path') else ''
                })

        # Context menu for stream selection
        context_menu = []
        url = self.addon.get_url(
            action='select_stream_manual',
            content_type='movie',
            tmdb_id=tmdb_id,
            title=title,
            year=year,
            handle=self.handle
        )

        context_menu.append((
            self._get_string('select_stream'),
            f"RunPlugin({url})"
        ))

        # URL
        url = self.addon.get_url(
            action='play_movie',
            tmdb_id=tmdb_id,
            title=title,
            year=year
        )

        self.add_item(label, url, is_folder=False, art=art, info=info, cast=cast, context_menu=context_menu)

    def add_tvshow_item(self, show, is_search_result=False):
        """Add a TV show item to the directory"""
        tmdb_id = show.get('id')
        title = show.get('name', 'Unknown')
        year = show.get('first_air_date', '')[:4] if show.get('first_air_date') else ''

        # Get full details
        details = self.tmdb.get_tv_details(tmdb_id) if tmdb_id else None

        # Build label
        label = f"[B]{title}[/B]"
        if year:
            label += f" ({year})"
        if details and details.get('vote_average'):
            rating = details['vote_average']
            label += f" [COLOR yellow]{rating:.1f}★[/COLOR]"

        # Build artwork
        art = {}
        if details:
            if details.get('poster_path'):
                art['poster'] = self.tmdb.get_poster(details['poster_path'], 'w500')
                art['thumb'] = self.tmdb.get_poster(details['poster_path'], 'w342')
            if details.get('backdrop_path'):
                art['fanart'] = self.tmdb.get_backdrop(details['backdrop_path'])

        if not art.get('poster'):
            art['poster'] = 'DefaultTVShows.png'
            art['thumb'] = 'DefaultTVShows.png'

        # Build info
        info = {'title': title, 'mediatype': 'tvshow'}
        if year:
            info['year'] = int(year) if year.isdigit() else 0
            info['premiered'] = show.get('first_air_date', '')
        if details:
            info['plot'] = details.get('overview', '')
            info['rating'] = float(details.get('vote_average', 0))
            info['votes'] = str(details.get('vote_count', 0))

            genres = [g['name'] for g in details.get('genres', [])]
            if genres:
                info['genre'] = ' / '.join(genres)

            info['status'] = details.get('status', '')

        # Build cast
        cast = []
        if details and details.get('credits'):
            for person in details['credits'].get('cast', [])[:10]:
                cast.append({
                    'name': person.get('name', ''),
                    'role': person.get('character', ''),
                    'thumbnail': self.tmdb.get_image_url(person.get('profile_path'), 'w185')
                                if person.get('profile_path') else ''
                })

        # URL
        url = self.addon.get_url(action='tv_show', tmdb_id=tmdb_id)

        self.add_item(label, url, is_folder=True, art=art, info=info, cast=cast)

    def add_season_item(self, show, season):
        """Add a season item to the directory"""
        show_title = show.get('name', 'Unknown')
        tmdb_id = show.get('id')
        season_num = season.get('season_number', 0)
        episode_count = season.get('episode_count', 0)

        # Translated season label
        label = f"{self._get_string('season')} {season_num}"
        if episode_count > 0:
            label += f" ({episode_count} {self._get_string('episodes')})"

        # Artwork
        art = {}
        if season.get('poster_path'):
            art['poster'] = self.tmdb.get_poster(season['poster_path'], 'w500')
            art['thumb'] = self.tmdb.get_poster(season['poster_path'], 'w342')
        elif show.get('poster_path'):
            art['poster'] = self.tmdb.get_poster(show['poster_path'], 'w500')
            art['thumb'] = self.tmdb.get_poster(show['poster_path'], 'w342')

        if not art.get('poster'):
            art['poster'] = 'DefaultFolder.png'
            art['thumb'] = 'DefaultFolder.png'

        # Info
        info = {
            'title': f"{self._get_string('season')} {season_num}",
            'mediatype': 'season',
            'season': season_num
        }
        if season.get('air_date'):
            info['premiered'] = season['air_date']
        if season.get('overview'):
            info['plot'] = season['overview']

        # URL
        url = self.addon.get_url(action='tv_season', tmdb_id=tmdb_id, season=season_num)

        self.add_item(label, url, is_folder=True, art=art, info=info)

    def add_episode_item(self, show, season, episode):
        """Add an episode item to the directory"""
        show_title = show.get('name', 'Unknown')
        tmdb_id = show.get('id')
        season_num = season.get('season_number', 0)
        episode_num = episode.get('episode_number', 0)
        episode_name = episode.get('name', f"{self._get_string('episode')} {episode_num}")

        # Build label
        label = f"{episode_num}. {episode_name}"
        if episode.get('vote_average'):
            rating = episode['vote_average']
            label += f" [COLOR yellow]{rating:.1f}★[/COLOR]"

        # Artwork
        art = {}
        if episode.get('still_path'):
            art['thumb'] = self.tmdb.get_still(episode['still_path'], 'w500')
            art['poster'] = self.tmdb.get_still(episode['still_path'], 'w500')
        elif season.get('poster_path'):
            art['poster'] = self.tmdb.get_poster(season['poster_path'], 'w500')
            art['thumb'] = self.tmdb.get_poster(season['poster_path'], 'w342')
        elif show.get('poster_path'):
            art['poster'] = self.tmdb.get_poster(show['poster_path'], 'w500')
            art['thumb'] = self.tmdb.get_poster(show['poster_path'], 'w342')

        if not art.get('thumb'):
            art['thumb'] = 'DefaultVideo.png'
            art['poster'] = 'DefaultVideo.png'

        # Info
        info = {
            'title': episode_name,
            'mediatype': 'episode',
            'season': season_num,
            'episode': episode_num,
            'tvshowtitle': show_title
        }
        if episode.get('overview'):
            info['plot'] = episode['overview']
        if episode.get('vote_average'):
            info['rating'] = float(episode['vote_average'])
        if episode.get('air_date'):
            info['aired'] = episode['air_date']
        if episode.get('runtime'):
            info['duration'] = episode['runtime'] * 60

        # Context menu for stream selection
        context_menu = []
        url = self.addon.get_url(
            action='select_stream_manual',
            content_type='episode',
            tmdb_id=tmdb_id,
            title=show_title,
            season=season_num,
            episode=episode_num,
            handle=self.handle
        )

        context_menu.append((
            self._get_string('select_stream'),
            f"RunPlugin({url})"
        ))

        # URL
        url = self.addon.get_url(
            action='play_episode',
            tmdb_id=tmdb_id,
            show_title=show_title,
            season=season_num,
            episode=episode_num,
            episode_title=episode_name
        )

        self.add_item(label, url, is_folder=False, art=art, info=info, context_menu=context_menu)
