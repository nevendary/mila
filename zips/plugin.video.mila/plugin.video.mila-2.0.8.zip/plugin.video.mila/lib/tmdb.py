# -*- coding: utf-8 -*-
# TMDB API wrapper - WITH PROPER LANGUAGE SUPPORT FOR ALL METADATA
import requests
import time
import hashlib
import json
import xbmc
from lib.utils import log, cache_get, cache_set

class TMDB:
    def __init__(self, addon):
        self.api_key = addon.getSetting('tmdb_api_key') or "9567cc1179d493c3b22f0682dbdf2e42"
        self.addon = addon
        self.base_url = "https://api.themoviedb.org/3"
        self.image_url = "https://image.tmdb.org/t/p/"
        
        # Get language from settings - THIS IS THE KEY!
        self.language = addon.getSetting('tmdb_language')
        if not self.language or self.language == '':
            # Default to English if not set
            self.language = 'en-US'
            
        log(f"🎯 TMDB using language: {self.language}")

        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json',
            'Content-Type': 'application/json'
        })

    def _get(self, endpoint, params=None, language_override=None):
        """Make TMDB API request with caching and PROPER LANGUAGE HANDLING"""
        if params is None:
            params = {}

        # CRITICAL: Always include language parameter!
        # Use override if provided, otherwise use instance language
        lang = language_override if language_override else self.language
        params['language'] = lang
        
        # Always add API key
        params['api_key'] = self.api_key
        
        # Include fallback images for missing localized artwork
        params['include_image_language'] = f"{lang.split('-')[0]},en,null"

        # Create cache key
        param_str = json.dumps(params, sort_keys=True)
        cache_key = f"tmdb_{endpoint}_{hashlib.md5(param_str.encode()).hexdigest()}"

        # Try cache first (24 hour TTL)
        cached = cache_get(cache_key, ttl=86400)
        if cached:
            log(f"📦 Cache hit: {endpoint} ({lang})")
            return cached

        try:
            url = f"{self.base_url}/{endpoint}"
            log(f"🌐 TMDB request: {url} | language={lang}")

            response = self.session.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                cache_set(cache_key, data)
                return data
            elif response.status_code == 429:
                log(f"⏳ TMDB rate limit hit, waiting...")
                time.sleep(2)
                return self._get(endpoint, params, language_override)
            else:
                log(f"❌ TMDB error {response.status_code}: {endpoint}")

        except Exception as e:
            log(f"❌ TMDB exception: {str(e)}")

        return None

    # ===== MOVIES - ALL METHODS NOW USE self.language =====
    
    def get_movie_details(self, tmdb_id):
        """Get movie details with credits - IN USER'S LANGUAGE"""
        return self._get(f"movie/{tmdb_id}", {
            'append_to_response': 'credits,release_dates,videos,translations,keywords'
        })

    def search_movie(self, query):
        """Search for movies - RESULTS IN USER'S LANGUAGE"""
        log(f"🔍 Searching movies: {query} in {self.language}")
        data = self._get("search/movie", {
            'query': query,
            'include_adult': False
        })
        if data and 'results' in data:
            log(f"📊 Found {len(data['results'])} movie results")
            return data['results']
        return []

    def get_popular_movies(self):
        """Get popular movies - IN USER'S LANGUAGE"""
        data = self._get("movie/popular")
        return data.get('results', []) if data else []

    def get_top_rated_movies(self):
        """Get top rated movies - IN USER'S LANGUAGE"""
        data = self._get("movie/top_rated")
        return data.get('results', []) if data else []

    # ===== TV SHOWS - ALL METHODS NOW USE self.language =====
    
    def get_tv_details(self, tmdb_id):
        """Get TV show details - IN USER'S LANGUAGE"""
        return self._get(f"tv/{tmdb_id}", {
            'append_to_response': 'credits,content_ratings,translations,keywords'
        })

    def get_tv_season(self, tmdb_id, season_num):
        """Get TV season details - IN USER'S LANGUAGE"""
        return self._get(f"tv/{tmdb_id}/season/{season_num}")

    def get_episode_details(self, tmdb_id, season_num, episode_num):
        """Get TV episode details - IN USER'S LANGUAGE"""
        return self._get(f"tv/{tmdb_id}/season/{season_num}/episode/{episode_num}")

    def search_tv(self, query):
        """Search for TV shows - RESULTS IN USER'S LANGUAGE"""
        log(f"🔍 Searching TV: {query} in {self.language}")
        data = self._get("search/tv", {
            'query': query,
            'include_adult': False
        })
        if data and 'results' in data:
            log(f"📊 Found {len(data['results'])} TV results")
            return data['results']
        return []

    def get_popular_tv(self):
        """Get popular TV shows - IN USER'S LANGUAGE"""
        data = self._get("tv/popular")
        return data.get('results', []) if data else []

    def get_top_rated_tv(self):
        """Get top rated TV shows - IN USER'S LANGUAGE"""
        data = self._get("tv/top_rated")
        return data.get('results', []) if data else []

    # ===== LISTS =====
    
    def get_list(self, list_type):
        """Get TMDB list by type - ALL IN USER'S LANGUAGE"""
        if list_type == 'popular_movies':
            return self.get_popular_movies()
        elif list_type == 'top_rated_movies':
            return self.get_top_rated_movies()
        elif list_type == 'popular_tv':
            return self.get_popular_tv()
        elif list_type == 'top_rated_tv':
            return self.get_top_rated_tv()
        return []

    # ===== IMAGE HELPERS =====
    
    def get_image_url(self, path, size='original'):
        if not path:
            return ''
        return f"{self.image_url}{size}{path}"

    def get_poster(self, path, size='w500'):
        return self.get_image_url(path, size)

    def get_backdrop(self, path, size='original'):
        return self.get_image_url(path, size)

    def get_still(self, path, size='w500'):
        return self.get_image_url(path, size)

    # ===== LOCALIZED TITLES - YOUR EXISTING CODE PRESERVED! =====
    # These methods are for when you need SPECIFIC languages regardless of settings
    
    def get_movie_localized_titles(self, tmdb_id):
        """Get movie titles in Czech, Croatian, Serbian - FOR SPECIFIC LANGUAGE NEEDS"""
        titles = {
            'english': None,
            'czech': None,
            'croatian': None,
            'serbian': None,
            'original': None
        }

        try:
            # Get English title (fallback)
            en_data = self._get(f"movie/{tmdb_id}", {'language': 'en-US'})
            if en_data:
                titles['english'] = en_data.get('title')
                titles['original'] = en_data.get('original_title')

            # Try Czech title
            cz_data = self._get(f"movie/{tmdb_id}", {'language': 'cs-CZ'})
            if cz_data and cz_data.get('title'):
                cz_title = cz_data.get('title')
                if cz_title != titles['english']:
                    titles['czech'] = cz_title

            # Try Croatian title
            hr_data = self._get(f"movie/{tmdb_id}", {'language': 'hr-HR'})
            if hr_data and hr_data.get('title'):
                hr_title = hr_data.get('title')
                if hr_title != titles['english']:
                    titles['croatian'] = hr_title

            # Try Serbian title
            sr_data = self._get(f"movie/{tmdb_id}", {'language': 'sr-RS'})
            if sr_data and sr_data.get('title'):
                sr_title = sr_data.get('title')
                if sr_title != titles['english']:
                    titles['serbian'] = sr_title

            # Fallback to English
            if not titles['czech']:
                titles['czech'] = titles['english']
            if not titles['croatian']:
                titles['croatian'] = titles['english']
            if not titles['serbian']:
                titles['serbian'] = titles['english']

        except Exception as e:
            log(f"Error getting localized titles: {str(e)}")
            titles['czech'] = titles.get('english', '')
            titles['croatian'] = titles.get('english', '')
            titles['serbian'] = titles.get('english', '')

        return titles

    def get_tv_localized_titles(self, tmdb_id):
        """Get TV show titles in Czech, Croatian, Serbian - FOR SPECIFIC LANGUAGE NEEDS"""
        titles = {
            'english': None,
            'czech': None,
            'croatian': None,
            'serbian': None,
            'original': None
        }

        try:
            # Get English title
            en_data = self._get(f"tv/{tmdb_id}", {'language': 'en-US'})
            if en_data:
                titles['english'] = en_data.get('name')
                titles['original'] = en_data.get('original_name')

            # Try Czech title
            cz_data = self._get(f"tv/{tmdb_id}", {'language': 'cs-CZ'})
            if cz_data and cz_data.get('name'):
                cz_title = cz_data.get('name')
                if cz_title != titles['english']:
                    titles['czech'] = cz_title

            # Try Croatian title
            hr_data = self._get(f"tv/{tmdb_id}", {'language': 'hr-HR'})
            if hr_data and hr_data.get('name'):
                hr_title = hr_data.get('name')
                if hr_title != titles['english']:
                    titles['croatian'] = hr_title

            # Try Serbian title
            sr_data = self._get(f"tv/{tmdb_id}", {'language': 'sr-RS'})
            if sr_data and sr_data.get('name'):
                sr_title = sr_data.get('name')
                if sr_title != titles['english']:
                    titles['serbian'] = sr_title

            # Fallback
            if not titles['czech']:
                titles['czech'] = titles['english']
            if not titles['croatian']:
                titles['croatian'] = titles['english']
            if not titles['serbian']:
                titles['serbian'] = titles['english']

        except Exception as e:
            log(f"Error getting localized titles: {str(e)}")
            titles['czech'] = titles.get('english', '')
            titles['croatian'] = titles.get('english', '')
            titles['serbian'] = titles.get('english', '')

        return titles

    # ===== NEW: HELPER TO GET CURRENT LANGUAGE TITLE =====
    
    def get_title_in_current_language(self, tmdb_id, media_type='movie'):
        """Get title in user's current language setting"""
        try:
            if media_type == 'movie':
                data = self._get(f"movie/{tmdb_id}")
                if data:
                    return data.get('title')
            else:
                data = self._get(f"tv/{tmdb_id}")
                if data:
                    return data.get('name')
        except Exception as e:
            log(f"Error getting title in current language: {str(e)}")
        return None
