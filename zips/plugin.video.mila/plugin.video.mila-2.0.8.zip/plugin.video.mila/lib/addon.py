# -*- coding: utf-8 -*-
# Core addon class and router - WITH SEARCH AND WATCH HISTORY
import sys
import re
import xbmc
import xbmcaddon
import xbmcplugin
from urllib.parse import parse_qsl

from lib.utils import log
from lib.tmdb import TMDB
from lib.websharder import WebSharder
from lib.gui import GUI
from lib.streaming import StreamSelector
from lib.history import HistoryManager

class MILA:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.addon_id = self.addon.getAddonInfo('id')
        self.handle = int(sys.argv[1])
        self.url = sys.argv[0]

        # Initialize modules
        self.tmdb = TMDB(self.addon)
        self.websharder = WebSharder()
        self.gui = GUI(self)
        self.stream_selector = StreamSelector(self.addon, self.websharder)
        self.history = HistoryManager()

    def get_url(self, **kwargs):
        """Create plugin URL"""
        from urllib.parse import urlencode
        return self.url + '?' + urlencode(kwargs)

    def router(self, paramstring):
        """Route to appropriate function"""
        params = dict(parse_qsl(paramstring))
        action = params.get('action', 'main_menu')

        log(f"Routing: {action}")

        # ===== MAIN MENU =====
        if action == 'main_menu':
            self.main_menu()

        # ===== HISTORY ACTIONS =====
        elif action == 'search_history':
            self.show_search_history()
        elif action == 'watch_history':
            self.show_watch_history()
        elif action == 'clear_search_history':
            self.history.clear_search_history()
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'clear_watch_history':
            self.history.clear_watch_history()
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'remove_watch_item':
            index = params.get('index')
            if index:
                self.history.remove_from_watch_history(int(index))
        elif action == 'remove_search_item':
            query = params.get('query')
            if query:
                self.history.remove_search_item(query)
                xbmc.executebuiltin('Container.Refresh')
        elif action == 'search_from_history':
            query = params.get('query')
            if query:
                self.show_search_results(query)

        # ===== TMDB LISTS =====
        elif action == 'tmdb_list':
            list_type = params.get('list_type')
            list_name = params.get('list_name')
            self.show_tmdb_list(list_type, list_name)

        # ===== SEARCH =====
        elif action == 'search':
            self.search_menu()
        elif action == 'search_results':
            query = params.get('query', '')
            self.show_search_results(query)

        # ===== TV SHOWS =====
        elif action == 'tv_popular':
            self.show_tmdb_list('popular_tv', self.gui._get_string('popular_tv'))
        elif action == 'tv_top_rated':
            self.show_tmdb_list('top_rated_tv', self.gui._get_string('top_rated_tv'))
        elif action == 'tv_show':
            tmdb_id = params.get('tmdb_id')
            self.show_tv_show_seasons(tmdb_id)
        elif action == 'tv_season':
            tmdb_id = params.get('tmdb_id')
            season = params.get('season')
            self.show_tv_season_episodes(tmdb_id, season)

        # ===== MOVIES =====
        elif action == 'movie_popular':
            self.show_tmdb_list('popular_movies', self.gui._get_string('popular_movies'))
        elif action == 'movie_top_rated':
            self.show_tmdb_list('top_rated_movies', self.gui._get_string('top_rated_movies'))

        # ===== PLAYBACK =====
        elif action == 'play_movie':
            tmdb_id = params.get('tmdb_id')
            title = params.get('title')
            year = params.get('year')
            stream_id = params.get('stream_id')

            movie_details = self.tmdb.get_movie_details(tmdb_id)

            self.stream_selector.play_movie(
                tmdb_id=tmdb_id,
                title=title,
                year=year,
                stream_id=stream_id,
                handle=self.handle,
                movie_details=movie_details
            )

        elif action == 'play_episode':
            tmdb_id = params.get('tmdb_id')
            show_title = params.get('show_title')
            season = params.get('season')
            episode = params.get('episode')
            episode_title = params.get('episode_title', '')
            stream_id = params.get('stream_id')

            episode_details = self.tmdb.get_episode_details(tmdb_id, season, episode)
            show_details = self.tmdb.get_tv_details(tmdb_id)

            self.stream_selector.play_episode(
                tmdb_id=tmdb_id,
                show_title=show_title,
                season=season,
                episode=episode,
                episode_title=episode_title,
                stream_id=stream_id,
                handle=self.handle,
                episode_details=episode_details,
                show_details=show_details
            )

        elif action == 'select_stream_manual':
            tmdb_id = params.get('tmdb_id')
            content_type = params.get('content_type')
            title = params.get('title')
            year = params.get('year', '')
            season = params.get('season', '')
            episode = params.get('episode', '')
            handle = params.get('handle')

            clean_handle = None
            if handle:
                clean_handle = re.sub(r'[^\d-]', '', handle)

            self.stream_selector.manual_select(
                tmdb_id=tmdb_id,
                content_type=content_type,
                title=title,
                year=year,
                season=season,
                episode=episode,
                handle=clean_handle
            )

        elif action == 'clear_subtitles':
            from lib.opensubtitles import OpenSubtitles
            os = OpenSubtitles()
            os.clear_cache()
            xbmc.executebuiltin('Container.Refresh')

        else:
            self.main_menu()

    def main_menu(self):
        """Main menu with history sections - PROPER FORMATTING, NO EXTRA HEADERS"""
        xbmcplugin.setPluginCategory(self.handle, 'MILA')
        xbmcplugin.setContent(self.handle, 'files')

        # SEARCH
        self.gui.add_item(
            label=f'[B][COLOR yellow]{self.gui._get_string("search")}[/COLOR][/B]',
            url=self.get_url(action='search'),
            is_folder=True,
            art={'icon': 'DefaultSearch.png'}
        )

        # SEARCH HISTORY
        self.gui.add_item(
            label=f'[COLOR grey]{self.gui._get_string("search_history")}[/COLOR]',
            url=self.get_url(action='search_history'),
            is_folder=True,
            art={'icon': 'DefaultRecentlyAddedEpisodes.png'}
        )

        # WATCH HISTORY
        self.gui.add_item(
            label=f'[COLOR yellow]{self.gui._get_string("watch_history")}[/COLOR]',
            url=self.get_url(action='watch_history'),
            is_folder=True,
            art={'icon': 'DefaultVideoPlaylists.png'}
        )

        # MOVIES
        self.gui.add_item(
            label=f'[B][COLOR gold]{self.gui._get_string("popular_movies")}[/COLOR][/B]',
            url=self.get_url(action='movie_popular'),
            is_folder=True,
            art={'icon': 'DefaultMovies.png'}
        )
        self.gui.add_item(
            label=f'[B][COLOR gold]{self.gui._get_string("top_rated_movies")}[/COLOR][/B]',
            url=self.get_url(action='movie_top_rated'),
            is_folder=True,
            art={'icon': 'DefaultMovies.png'}
        )

        # TV SHOWS
        self.gui.add_item(
            label=f'[B][COLOR cyan]{self.gui._get_string("popular_tv")}[/COLOR][/B]',
            url=self.get_url(action='tv_popular'),
            is_folder=True,
            art={'icon': 'DefaultTVShows.png'}
        )
        self.gui.add_item(
            label=f'[B][COLOR cyan]{self.gui._get_string("top_rated_tv")}[/COLOR][/B]',
            url=self.get_url(action='tv_top_rated'),
            is_folder=True,
            art={'icon': 'DefaultTVShows.png'}
        )

        xbmcplugin.endOfDirectory(self.handle)

    def show_search_history(self):
        """Show search history"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('search_history'))
        xbmcplugin.setContent(self.handle, 'files')

        history = self.history.get_search_history()

        if not history:
            self.gui.add_item(
                label=f'[COLOR grey]{self.gui._get_string("no_search_history")}[/COLOR]',
                url='',
                is_folder=False,
                art={'icon': 'DefaultAddon.png'}
            )
        else:
            for item in history:
                query = item.get('query', '')

                context_menu = [
                    (
                        self.gui._get_string('remove_from_history'),
                        f'RunPlugin({self.get_url(action="remove_search_item", query=query)})'
                    ),
                    (
                        self.gui._get_string('clear_all'),
                        f'RunPlugin({self.get_url(action="clear_search_history")})'
                    )
                ]

                self.gui.add_item(
                    label=f'[COLOR white]{query}[/COLOR]',
                    url=self.get_url(action='search_results', query=query),
                    is_folder=True,
                    art={'icon': 'DefaultSearch.png'},
                    context_menu=context_menu
                )

        if history:
            self.gui.add_item(
                label=f'[COLOR red]{self.gui._get_string("clear_all")}[/COLOR]',
                url=self.get_url(action='clear_search_history'),
                is_folder=False,
                art={'icon': 'DefaultAddon.png'}
            )

        xbmcplugin.endOfDirectory(self.handle)

    def show_watch_history(self):
        """Show watch history"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('watch_history'))
        xbmcplugin.setContent(self.handle, 'videos')

        history = self.history.get_watch_history()

        if not history:
            self.gui.add_item(
                label=f'[COLOR grey]{self.gui._get_string("no_watch_history")}[/COLOR]',
                url='',
                is_folder=False,
                art={'icon': 'DefaultAddon.png'}
            )
        else:
            for index, item in enumerate(history):
                item_type = item.get('type', '')

                if item_type == 'movie':
                    title = item.get('title', 'Unknown')
                    year = item.get('year', '')
                    tmdb_id = item.get('tmdb_id')

                    label = f'[COLOR gold]{title}[/COLOR]'
                    if year:
                        label += f' [COLOR grey]({year})[/COLOR]'

                    url = self.get_url(
                        action='play_movie',
                        tmdb_id=tmdb_id,
                        title=title,
                        year=year
                    )

                    art = {'icon': 'DefaultMovies.png'}
                    if item.get('poster'):
                        art['thumb'] = f"https://image.tmdb.org/t/p/w185{item['poster']}"

                else:
                    show_title = item.get('show_title', 'Unknown')
                    season = item.get('season', 0)
                    episode = item.get('episode', 0)
                    episode_title = item.get('title', '')
                    tmdb_id = item.get('tmdb_id')

                    label = f'[COLOR cyan]{show_title}[/COLOR] [COLOR grey]- S{int(season):02d}E{int(episode):02d}[/COLOR]'
                    if episode_title and episode_title != f'S{season}E{episode}':
                        label += f' [COLOR white]- {episode_title}[/COLOR]'

                    url = self.get_url(
                        action='play_episode',
                        tmdb_id=tmdb_id,
                        show_title=show_title,
                        season=season,
                        episode=episode,
                        episode_title=episode_title
                    )

                    art = {'icon': 'DefaultTVShows.png'}
                    if item.get('poster'):
                        art['thumb'] = f"https://image.tmdb.org/t/p/w185{item['poster']}"

                context_menu = [
                    (
                        self.gui._get_string('remove_from_history'),
                        f'RunPlugin({self.get_url(action="remove_watch_item", index=index)})'
                    )
                ]

                self.gui.add_item(
                    label=label,
                    url=url,
                    is_folder=False,
                    art=art,
                    context_menu=context_menu
                )

            self.gui.add_item(
                label=f'[COLOR red]{self.gui._get_string("clear_all")}[/COLOR]',
                url=self.get_url(action='clear_watch_history'),
                is_folder=False,
                art={'icon': 'DefaultAddon.png'}
            )

        xbmcplugin.endOfDirectory(self.handle)

    def search_menu(self):
        """Show search dialog and save to history"""
        keyboard = xbmc.Keyboard('', self.gui._get_string('search'))
        keyboard.doModal()

        if keyboard.isConfirmed():
            query = keyboard.getText()
            if query:
                self.history.add_search(query)
                self.show_search_results(query)

    def show_search_results(self, query):
        """Search TMDB and show results"""
        xbmcplugin.setPluginCategory(self.handle, f'{self.gui._get_string("search")}: {query}')
        xbmcplugin.setContent(self.handle, 'files')

        movies = self.tmdb.search_movie(query)
        tv_shows = self.tmdb.search_tv(query)

        total = len(movies) + len(tv_shows)

        self.gui.add_item(
            label=f'[COLOR yellow]{self.gui._get_string("search_results", total)}[/COLOR]',
            url='',
            is_folder=False,
            art={'icon': 'DefaultFolder.png'}
        )

        for movie in movies:
            self.gui.add_movie_item(movie, is_search_result=True)

        for show in tv_shows:
            self.gui.add_tvshow_item(show, is_search_result=True)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tmdb_list(self, list_type, list_name):
        """Show TMDB list (popular, top rated)"""
        xbmcplugin.setPluginCategory(self.handle, list_name)

        items = self.tmdb.get_list(list_type)

        if 'movie' in list_type:
            xbmcplugin.setContent(self.handle, 'movies')
            for item in items:
                self.gui.add_movie_item(item)
        else:
            xbmcplugin.setContent(self.handle, 'tvshows')
            for item in items:
                self.gui.add_tvshow_item(item)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tv_show_seasons(self, tmdb_id):
        """Show seasons of a TV show"""
        show = self.tmdb.get_tv_details(tmdb_id)
        if not show:
            return

        show_name = show.get('name', 'TV Show')
        xbmcplugin.setPluginCategory(self.handle, show_name)
        xbmcplugin.setContent(self.handle, 'seasons')

        seasons = show.get('seasons', [])
        for season in seasons:
            season_num = season.get('season_number', 0)
            if season_num == 0:
                continue

            self.gui.add_season_item(show, season)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tv_season_episodes(self, tmdb_id, season_num):
        """Show episodes of a season"""
        show = self.tmdb.get_tv_details(tmdb_id)
        if not show:
            return

        season = self.tmdb.get_tv_season(tmdb_id, season_num)
        if not season:
            return

        show_title = show.get('name', '')
        xbmcplugin.setPluginCategory(
            self.handle,
            f'{show_title} - {self.gui._get_string("season")} {season_num}'
        )
        xbmcplugin.setContent(self.handle, 'episodes')

        episodes = season.get('episodes', [])
        for episode in episodes:
            self.gui.add_episode_item(show, season, episode)

        xbmcplugin.endOfDirectory(self.handle)

def run():
    """Entry point"""
    addon = MILA()
    if len(sys.argv) > 2:
        addon.router(sys.argv[2][1:])
    else:
        addon.router('')
