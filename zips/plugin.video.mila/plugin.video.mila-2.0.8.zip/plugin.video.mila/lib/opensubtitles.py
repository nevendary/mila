# -*- coding: utf-8 -*-
import os
import hashlib
import re
import requests
import xbmc
import xbmcaddon
import xbmcvfs
from lib.utils import log

_addon = xbmcaddon.Addon()

class OpenSubtitles:
    def __init__(self):
        self.base_url = "https://api.opensubtitles.com/api/v1"
        self.api_key = "zCGm5bsaqSEbglUDxYjPspRDkZI3Cjef"
        self.token = None
        self.user_agent = "MILA-Kodi-Addon/2.0.0"
        
        self.session = requests.Session()
        self.session.headers.update({
            'Api-Key': self.api_key,
            'Content-Type': 'application/json',
            'Accept': 'application/json',
            'User-Agent': self.user_agent
        })
        
        # Subtitle cache directory
        self.cache_dir = xbmcvfs.translatePath(_addon.getSetting('subtitle_folder') or 'special://temp/mila_subs/')
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)
    
    def get_kodi_language(self):
        """Get Kodi interface language - returns ISO 639-1 codes (cs, hr, en)"""
        try:
            lang = xbmc.getLanguage(xbmc.ISO_639_1).lower()
            log(f"OpenSubtitles: Kodi language detected: {lang}")
            
            # Only allow cs, hr, en - fallback to en for anything else
            if lang in ['cs', 'hr', 'en']:
                return lang
            else:
                return 'en'
        except:
            return 'en'
    
    def search_subtitles(self, tmdb_id, title, season=None, episode=None, year=None):
        """
        Search and return path to best subtitle file (string) or None
        Uses Kodi language setting - SILENT OPERATION
        """
        # Check if subtitles are enabled
        enabled = _addon.getSetting('subtitles_enabled') == 'true'
        if not enabled:
            return None
        
        # Get language from Kodi (cs, hr, en)
        language = self.get_kodi_language()
        
        params = {
            'tmdb_id': tmdb_id,
            'languages': language  # Direct ISO code - cs, hr, en
        }
        
        if season and episode:
            params['season_number'] = int(season)
            params['episode_number'] = int(episode)
            log(f"OpenSubtitles: Searching TV: {title} S{season}E{episode} [{language}]")
        else:
            log(f"OpenSubtitles: Searching movie: {title} ({year}) [{language}]")
        
        try:
            response = self.session.get(
                f"{self.base_url}/subtitles",
                params=params,
                timeout=15
            )
            
            if response.status_code != 200:
                return None
            
            data = response.json()
            subtitles = data.get('data', [])
            
            if not subtitles and language != 'en':
                # Try English as fallback
                log(f"OpenSubtitles: No {language} subs, trying English")
                params['languages'] = 'en'
                response = self.session.get(
                    f"{self.base_url}/subtitles",
                    params=params,
                    timeout=15
                )
                if response.status_code == 200:
                    data = response.json()
                    subtitles = data.get('data', [])
            
            if not subtitles:
                return None
            
            best_sub = self._get_best_subtitle(subtitles)
            if best_sub:
                return self._download_subtitle(best_sub, title, season, episode)
            
            return None
            
        except Exception as e:
            log(f"OpenSubtitles: Search error - {str(e)}")
            return None
    
    def _get_best_subtitle(self, subtitles):
        """Select best subtitle based on quality"""
        best_score = 0
        best_sub = None
        
        for sub_data in subtitles:
            attrs = sub_data.get('attributes', {})
            score = 0
            
            # Prefer SRT format
            if attrs.get('format') == 'srt':
                score += 50
            
            # Prefer non-hearing impaired
            if not attrs.get('hearing_impaired', False):
                score += 30
            
            # Prefer trusted uploaders
            if attrs.get('uploader', {}).get('trusted'):
                score += 20
            
            # Download count bonus
            download_count = attrs.get('download_count', 0)
            score += min(download_count / 1000, 20)
            
            # FPS match bonus
            if attrs.get('fps'):
                score += 10
            
            if score > best_score:
                best_score = score
                best_sub = sub_data
        
        return best_sub
    
    def _download_subtitle(self, subtitle_data, title, season=None, episode=None):
        """Download subtitle with sensible filename"""
        try:
            attrs = subtitle_data.get('attributes', {})
            files = attrs.get('files', [])
            
            if not files:
                return None
            
            file_id = files[0].get('file_id')
            if not file_id:
                return None
            
            # Get language code (cs, hr, en)
            lang_code = attrs.get('language', 'en')
            
            # Create sensible filename
            clean_title = re.sub(r'[^\w\s-]', '', title)
            clean_title = re.sub(r'[:\-]', ' ', clean_title)
            clean_title = ' '.join(clean_title.split())
            clean_title = clean_title.replace(' ', '.')
            
            if season is not None and episode is not None:
                filename = f"{clean_title}.S{int(season):02d}E{int(episode):02d}.{lang_code}.srt"
            else:
                filename = f"{clean_title}.{lang_code}.srt"
            
            cached_file = os.path.join(self.cache_dir, filename)
            
            # Check if already cached
            if os.path.exists(cached_file):
                log(f"OpenSubtitles: Using cached: {filename}")
                return cached_file
            
            # Get download link
            response = self.session.post(
                f"{self.base_url}/download",
                json={'file_id': file_id},
                timeout=15
            )
            
            if response.status_code != 200:
                return None
            
            download_url = response.json().get('link')
            if not download_url:
                return None
            
            # Download subtitle
            sub_response = requests.get(
                download_url,
                headers={'User-Agent': self.user_agent},
                timeout=15
            )
            
            if sub_response.status_code == 200:
                with open(cached_file, 'wb') as f:
                    f.write(sub_response.content)
                log(f"OpenSubtitles: Downloaded: {filename}")
                return cached_file
            else:
                return None
                
        except Exception as e:
            log(f"OpenSubtitles: Download error - {str(e)}")
            return None
    
    def clear_cache(self):
        """Clear subtitle cache"""
        try:
            import shutil
            if os.path.exists(self.cache_dir):
                shutil.rmtree(self.cache_dir)
                os.makedirs(self.cache_dir)
                log("OpenSubtitles: Cache cleared")
                return True
        except Exception as e:
            log(f"OpenSubtitles: Clear cache error - {str(e)}")
            return False
