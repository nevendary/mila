# -*- coding: utf-8 -*-
# TMDB API wrapper
import requests
import time
import hashlib
import json
from lib.utils import log, cache_get, cache_set

class TMDB:
    def __init__(self, addon):
        self.api_key = addon.getSetting('tmdb_api_key') or "9567cc1179d493c3b22f0682dbdf2e42"
        self.language = addon.getSetting('tmdb_language') or 'en-US'
        self.base_url = "https://api.themoviedb.org/3"
        self.image_url = "https://image.tmdb.org/t/p/"

        self.session = requests.Session()
        self.session.headers.update({
            'Accept': 'application/json'
        })

    def _get(self, endpoint, params=None):
        """Make TMDB API request with caching"""
        if params is None:
            params = {}

        # Always add language
        params['language'] = params.get('language', self.language)
        # Add API key as parameter
        params['api_key'] = self.api_key

        # Create consistent cache key
        param_str = json.dumps(params, sort_keys=True)
        cache_key = f"tmdb_{endpoint}_{hashlib.md5(param_str.encode()).hexdigest()}"

        # Try cache first
        cached = cache_get(cache_key, ttl=86400)
        if cached:
            return cached

        try:
            url = f"{self.base_url}/{endpoint}"
            log(f"TMDB request: {url}")

            response = self.session.get(url, params=params, timeout=10)

            if response.status_code == 200:
                data = response.json()
                cache_set(cache_key, data)
                return data
            elif response.status_code == 429:
                log(f"TMDB rate limit hit, waiting...")
                time.sleep(2)
                return self._get(endpoint, params)
            else:
                log(f"TMDB error {response.status_code}: {endpoint}")

        except Exception as e:
            log(f"TMDB exception: {str(e)}")

        return None

    # ===== Movies =====
    def get_movie_details(self, tmdb_id):
        """Get movie details with credits"""
        return self._get(f"movie/{tmdb_id}", {'append_to_response': 'credits,release_dates,videos'})

    def search_movie(self, query):
        """Search for movies"""
        log(f"Searching TMDB for movie: {query}")
        data = self._get("search/movie", {'query': query})
        if data and 'results' in data:
            log(f"Found {len(data['results'])} movie results")
            return data['results']
        return []

    def get_popular_movies(self):
        """Get popular movies"""
        data = self._get("movie/popular")
        return data.get('results', []) if data else []

    def get_top_rated_movies(self):
        """Get top rated movies"""
        data = self._get("movie/top_rated")
        return data.get('results', []) if data else []

    # ===== TV Shows =====
    def get_tv_details(self, tmdb_id):
        """Get TV show details"""
        return self._get(f"tv/{tmdb_id}", {'append_to_response': 'credits,content_ratings'})

    def get_tv_season(self, tmdb_id, season_num):
        """Get TV season details"""
        return self._get(f"tv/{tmdb_id}/season/{season_num}")

    def get_tv_episode(self, tmdb_id, season_num, episode_num):
        """Get TV episode details"""
        return self._get(f"tv/{tmdb_id}/season/{season_num}/episode/{episode_num}")

    def search_tv(self, query):
        """Search for TV shows"""
        log(f"Searching TMDB for TV: {query}")
        data = self._get("search/tv", {'query': query})
        if data and 'results' in data:
            log(f"Found {len(data['results'])} TV results")
            return data['results']
        return []

    def get_popular_tv(self):
        """Get popular TV shows"""
        data = self._get("tv/popular")
        return data.get('results', []) if data else []

    def get_top_rated_tv(self):
        """Get top rated TV shows"""
        data = self._get("tv/top_rated")
        return data.get('results', []) if data else []

    # ===== Lists =====
    def get_list(self, list_type):
        """Get TMDB list by type"""
        if list_type == 'popular_movies':
            return self.get_popular_movies()
        elif list_type == 'top_rated_movies':
            return self.get_top_rated_movies()
        elif list_type == 'popular_tv':
            return self.get_popular_tv()
        elif list_type == 'top_rated_tv':
            return self.get_top_rated_tv()
        return []

    # ===== Image Helpers =====
    def get_image_url(self, path, size='original'):
        if not path:
            return ''
        return f"{self.image_url}{size}{path}"

    def get_poster(self, path, size='w500'):
        return self.get_image_url(path, size)

    def get_backdrop(self, path, size='original'):
        return self.get_image_url(path, size)

    def get_still(self, path, size='w500'):
        return self.get_image_url(path, size)

    # ===== LOCALIZED TITLES - FIXED TO ACTUALLY WORK =====
    def get_movie_localized_titles(self, tmdb_id):
        """Get movie titles in Czech, Croatian, Serbian - ACTUALLY WORKS"""
        titles = {
            'english': None,
            'czech': None,
            'croatian': None,
            'serbian': None,
            'original': None
        }

        try:
            # 1. Get English and original title
            en_data = self._get(f"movie/{tmdb_id}", {'language': 'en-US'})
            if en_data:
                titles['english'] = en_data.get('title')
                titles['original'] = en_data.get('original_title')
                log(f"  Original title: {titles['original']}")

            # 2. Try to get Czech title - THIS IS THE IMPORTANT PART
            cz_data = self._get(f"movie/{tmdb_id}", {'language': 'cs-CZ'})
            if cz_data and cz_data.get('title'):
                cz_title = cz_data.get('title')
                # Only use if it's actually different from English
                if cz_title != titles['english']:
                    titles['czech'] = cz_title
                    log(f"  Czech title from cs-CZ: {cz_title}")

            # 3. If no Czech title yet, check if original title has Czech characters
            if not titles['czech'] and titles['original']:
                if any(c in titles['original'] for c in 'áčďéěíňóřšťúůýž'):
                    titles['czech'] = titles['original']
                    log(f"  Using original title as Czech: {titles['czech']}")

            # 4. Try alternative titles (Czech Republic)
            if not titles['czech']:
                alt_data = self._get(f"movie/{tmdb_id}/alternative_titles")
                if alt_data:
                    for title_entry in alt_data.get('titles', []):
                        if title_entry.get('iso_3166_1') == 'CZ':
                            titles['czech'] = title_entry.get('title')
                            log(f"  Found Czech title in alternatives: {titles['czech']}")
                            break

            # 5. Try translations
            if not titles['czech']:
                trans_data = self._get(f"movie/{tmdb_id}/translations")
                if trans_data:
                    for translation in trans_data.get('translations', []):
                        if translation.get('iso_639_1') == 'cs':
                            titles['czech'] = translation.get('data', {}).get('title')
                            log(f"  Found Czech title in translations: {titles['czech']}")
                            break

            # Croatian titles
            hr_data = self._get(f"movie/{tmdb_id}", {'language': 'hr-HR'})
            if hr_data and hr_data.get('title'):
                hr_title = hr_data.get('title')
                if hr_title != titles['english']:
                    titles['croatian'] = hr_title
                    log(f"  Croatian title: {hr_title}")

            # Serbian titles
            sr_data = self._get(f"movie/{tmdb_id}", {'language': 'sr-RS'})
            if sr_data and sr_data.get('title'):
                sr_title = sr_data.get('title')
                if sr_title != titles['english']:
                    titles['serbian'] = sr_title
                    log(f"  Serbian title: {sr_title}")

            # If we still don't have a Czech title, use the English one (but log it)
            if not titles['czech']:
                titles['czech'] = titles['english']
                log(f"  No Czech title found, using English: {titles['czech']}")

        except Exception as e:
            log(f"Error getting localized titles: {str(e)}")
            # Fallback to English
            titles['czech'] = titles.get('english', '')
            titles['croatian'] = titles.get('english', '')
            titles['serbian'] = titles.get('english', '')

        return titles

    def get_tv_localized_titles(self, tmdb_id):
        """Get TV show titles in Czech, Croatian, Serbian - ACTUALLY WORKS"""
        titles = {
            'english': None,
            'czech': None,
            'croatian': None,
            'serbian': None,
            'original': None
        }

        try:
            # 1. Get English and original title
            en_data = self._get(f"tv/{tmdb_id}", {'language': 'en-US'})
            if en_data:
                titles['english'] = en_data.get('name')
                titles['original'] = en_data.get('original_name')
                log(f"  Original title: {titles['original']}")

            # 2. Try Czech title
            cz_data = self._get(f"tv/{tmdb_id}", {'language': 'cs-CZ'})
            if cz_data and cz_data.get('name'):
                cz_title = cz_data.get('name')
                if cz_title != titles['english']:
                    titles['czech'] = cz_title
                    log(f"  Czech title from cs-CZ: {cz_title}")

            # 3. Check original title for Czech characters
            if not titles['czech'] and titles['original']:
                if any(c in titles['original'] for c in 'áčďéěíňóřšťúůýž'):
                    titles['czech'] = titles['original']
                    log(f"  Using original title as Czech: {titles['czech']}")

            # 4. Try alternative titles
            if not titles['czech']:
                alt_data = self._get(f"tv/{tmdb_id}/alternative_titles")
                if alt_data:
                    for title_entry in alt_data.get('results', []):
                        if title_entry.get('iso_3166_1') == 'CZ':
                            titles['czech'] = title_entry.get('title')
                            log(f"  Found Czech title in alternatives: {titles['czech']}")
                            break

            # 5. Try translations
            if not titles['czech']:
                trans_data = self._get(f"tv/{tmdb_id}/translations")
                if trans_data:
                    for translation in trans_data.get('translations', []):
                        if translation.get('iso_639_1') == 'cs':
                            titles['czech'] = translation.get('data', {}).get('name')
                            log(f"  Found Czech title in translations: {titles['czech']}")
                            break

            # Croatian
            hr_data = self._get(f"tv/{tmdb_id}", {'language': 'hr-HR'})
            if hr_data and hr_data.get('name'):
                hr_title = hr_data.get('name')
                if hr_title != titles['english']:
                    titles['croatian'] = hr_title
                    log(f"  Croatian title: {hr_title}")

            # Serbian
            sr_data = self._get(f"tv/{tmdb_id}", {'language': 'sr-RS'})
            if sr_data and sr_data.get('name'):
                sr_title = sr_data.get('name')
                if sr_title != titles['english']:
                    titles['serbian'] = sr_title
                    log(f"  Serbian title: {sr_title}")

            # Fallback
            if not titles['czech']:
                titles['czech'] = titles['english']
                log(f"  No Czech title found, using English: {titles['czech']}")

        except Exception as e:
            log(f"Error getting localized titles: {str(e)}")
            titles['czech'] = titles.get('english', '')
            titles['croatian'] = titles.get('english', '')
            titles['serbian'] = titles.get('english', '')

        return titles
