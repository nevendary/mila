# -*- coding: utf-8 -*-
# Stream selection, ranking, and playback with OpenSubtitles support
import xbmc
import xbmcgui
import xbmcplugin
import sys
import os
import re
from urllib.parse import quote_plus
from lib.utils import log, popinfo, poperror
from lib.opensubtitles import OpenSubtitles
from lib.tmdb import TMDB

class StreamSelector:
    def __init__(self, addon, websharder):
        self.addon = addon
        self.websharder = websharder
        self.handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
        self.opensubtitles = OpenSubtitles()
        self.tmdb = TMDB(addon)

    def play_movie(self, tmdb_id, title, year):
        """Search and play movie with localized titles"""
        log(f"🎬 play_movie called: {title} ({year}) TMDB ID: {tmdb_id}")
        log(f"Using handle: {self.handle}")

        # Check if WebSharder is logged in
        if not self.websharder.token:
            log("WebSharder not logged in, attempting login...")
            if not self.websharder.login():
                poperror("WebShare login failed! Check username/password in settings.")
                return

        # Get localized titles from TMDB
        localized = self.tmdb.get_movie_localized_titles(tmdb_id)
        self.websharder.set_localized_titles(
            english_title=localized.get('english', title),
            czech_title=localized.get('czech'),
            croatian_title=localized.get('croatian'),
            serbian_title=localized.get('serbian')
        )

        # Show searching dialog
        progress = xbmcgui.DialogProgress()
        progress.create("WebShare Search", f"Searching for:\n{title} ({year})")

        # Search WebShare
        files = self.websharder.search_movie(title, year)
        log(f"WebShare search returned {len(files)} files")

        progress.close()

        if not files:
            popinfo(f"No files found for: {title} ({year})")
            return

        # Check autoplay setting
        autoplay = self.addon.getSetting('autoplay') == 'true'
        skip_popup = self.addon.getSetting('skip_popup') == 'true'

        if autoplay and skip_popup:
            ranked = self.rank_streams(files)
            if ranked:
                best = ranked[0]['stream']
                log(f"Auto-playing best stream: {best['filename']}")
                self._play_direct(
                    best['ident'],
                    f"{title} ({year})",
                    tmdb_id=tmdb_id,
                    year=year
                )
                return
            else:
                self._show_selector(files, f"{title} ({year})", tmdb_id=tmdb_id, year=year, movie_title=title)
        else:
            self._show_selector(files, f"{title} ({year})", tmdb_id=tmdb_id, year=year, movie_title=title)

    def play_episode(self, tmdb_id, show_title, season, episode, episode_title=""):
        """Search and play TV episode with localized titles"""
        log(f"📺 play_episode called: {show_title} S{season}E{episode} TMDB ID: {tmdb_id}")
        log(f"Using handle: {self.handle}")

        # Check if WebSharder is logged in
        if not self.websharder.token:
            log("WebSharder not logged in, attempting login...")
            if not self.websharder.login():
                poperror("WebShare login failed! Check username/password in settings.")
                return

        # Get localized titles from TMDB
        localized = self.tmdb.get_tv_localized_titles(tmdb_id)
        self.websharder.set_localized_titles(
            english_title=localized.get('english', show_title),
            czech_title=localized.get('czech'),
            croatian_title=localized.get('croatian'),
            serbian_title=localized.get('serbian')
        )

        # Show searching dialog
        progress = xbmcgui.DialogProgress()
        progress.create("WebShare Search", f"Searching for:\n{show_title}\nS{season}E{episode}")

        # Search WebShare
        files = self.websharder.search_episode(show_title, season, episode)
        log(f"WebShare search returned {len(files)} files")

        progress.close()

        if not files:
            popinfo(f"No files found for: {show_title} S{season}E{episode}")
            return

        # Create display title
        if episode_title:
            display_title = f"{show_title} - S{season}E{episode} - {episode_title}"
        else:
            display_title = f"{show_title} S{season}E{episode}"

        # Check autoplay setting
        autoplay = self.addon.getSetting('autoplay') == 'true'
        skip_popup = self.addon.getSetting('skip_popup') == 'true'

        if autoplay and skip_popup:
            ranked = self.rank_streams(files)
            if ranked:
                best = ranked[0]['stream']
                log(f"Auto-playing best stream: {best['filename']}")
                self._play_direct(
                    best['ident'],
                    display_title,
                    tmdb_id=tmdb_id,
                    season=season,
                    episode=episode
                )
                return
            else:
                self._show_selector(files, display_title, tmdb_id=tmdb_id, season=season, episode=episode, show_title=show_title)
        else:
            self._show_selector(files, display_title, tmdb_id=tmdb_id, season=season, episode=episode, show_title=show_title)

    def manual_select(self, tmdb_id, content_type, title, year, season, episode):
        """Force manual selection via context menu - bypasses autoplay"""
        log(f"manual_select called: {content_type} - {title}")
        log(f"✅ Manual select using handle: {self.handle} (set from URL)")

        # Ensure we're logged in
        if not self.websharder.token:
            if not self.websharder.login():
                poperror("WebShare login failed!")
                return

        if content_type == 'movie':
            localized = self.tmdb.get_movie_localized_titles(tmdb_id)
            self.websharder.set_localized_titles(
                english_title=localized.get('english', title),
                czech_title=localized.get('czech'),
                croatian_title=localized.get('croatian'),
                serbian_title=localized.get('serbian')
            )

            progress = xbmcgui.DialogProgress()
            progress.create("WebShare Search", f"Searching for:\n{title} ({year})")
            files = self.websharder.search_movie(title, year)
            progress.close()

            if files:
                self._show_selector(files, f"{title} ({year})", force_manual=True, tmdb_id=tmdb_id, year=year, movie_title=title)
            else:
                popinfo(f"No files found for: {title}")
        else:
            localized = self.tmdb.get_tv_localized_titles(tmdb_id)
            self.websharder.set_localized_titles(
                english_title=localized.get('english', title),
                czech_title=localized.get('czech'),
                croatian_title=localized.get('croatian'),
                serbian_title=localized.get('serbian')
            )

            progress = xbmcgui.DialogProgress()
            progress.create("WebShare Search", f"Searching for:\n{title}\nS{season}E{episode}")
            files = self.websharder.search_episode(title, season, episode)
            progress.close()

            if files:
                display_title = f"{title} S{season}E{episode}"
                self._show_selector(files, display_title, force_manual=True, tmdb_id=tmdb_id, season=season, episode=episode, show_title=title)
            else:
                popinfo(f"No files found for: {title} S{season}E{episode}")

    def detect_audio_languages(self, filename):
        if not filename:
            return []
        filename_lower = filename.lower()
        languages = []
        lang_patterns = [
            (r'cz\.|czech|česky|cesky|\[cz\]|\(cz\)|\scz\s|\.cz\.|cz\s+audio|cz\s+dabing|cz\s+', 'Czech', 100),
            (r'sk\.|slovak|slovensky|\[sk\]|\(sk\)|\ssk\s|\.sk\.', 'Slovak', 90),
            (r'en\.|english|\[en\]|\(en\)|\sen\s|\.en\.', 'English', 80),
            (r'hr\.|croatian|\[hr\]|\(hr\)|\shr\s|\.hr\.', 'Croatian', 70),
            (r'sr\.|serbian|\[sr\]|\(sr\)|\ssr\s|\.sr\.', 'Serbian', 70),
        ]
        if 'multi' in filename_lower or 'vícejazyčný' in filename_lower:
            languages.append(('Multi', 50))
        for pattern, lang, priority in lang_patterns:
            if re.search(pattern, filename_lower):
                languages.append((lang, priority))
        unique_langs = {}
        for lang, priority in languages:
            if lang not in unique_langs or priority > unique_langs[lang]:
                unique_langs[lang] = priority
        sorted_langs = sorted(unique_langs.items(), key=lambda x: x[1], reverse=True)
        return [lang for lang, _ in sorted_langs]

    def rank_streams(self, streams):
        if not streams:
            return []
        preferred_lang = self.addon.getSetting('preferred_language') or 'Any'
        max_quality = self.addon.getSetting('max_quality') or '4K'
        autoplay_resolution = self.addon.getSetting('autoplay_resolution') or '1080p'
        prefer_hdr = self.addon.getSetting('prefer_hdr') == 'true'
        quality_scores = {'4K HDR': 100, '4K': 90, '1080p': 70, '720p': 50, 'SD': 30}
        max_quality_score = {'4K': 100, '1080p': 70, '720p': 50, '480p': 30}.get(max_quality, 100)
        target_quality_score = {'4K': 90, '1080p': 70, '720p': 50, '480p': 30}.get(autoplay_resolution, 70)
        ranked_streams = []
        for i, stream in enumerate(streams):
            score = 0
            quality = stream.get('quality', 'SD')
            quality_score = quality_scores.get(quality, 30)
            filename = stream.get('filename', '')
            languages = self.detect_audio_languages(filename)
            stream['languages'] = languages
            if quality_score <= max_quality_score:
                diff = abs(quality_score - target_quality_score)
                if diff == 0:
                    score += 100
                elif diff == 20:
                    score += 80
                elif diff == 40:
                    score += 60
                else:
                    score += 40 - diff
            else:
                score -= 50
            if preferred_lang != 'Any':
                if preferred_lang in languages:
                    score += 200
                    if languages and languages[0] == preferred_lang:
                        score += 100
                elif 'Czech' in languages:
                    score += 150
                elif 'Slovak' in languages:
                    score += 120
                elif 'Croatian' in languages:
                    score += 80
                elif 'Serbian' in languages:
                    score += 80
                elif 'English' in languages:
                    score += 50
                elif languages:
                    score += 20
            else:
                if 'Czech' in languages:
                    score += 100
                elif 'Slovak' in languages:
                    score += 80
                elif languages:
                    score += 40
                else:
                    score += 10
            if stream.get('hdr', False):
                if prefer_hdr:
                    score += 50
                else:
                    score -= 20
            try:
                size_mb = int(stream.get('size', 0)) / (1024 * 1024)
                if size_mb > 0:
                    size_score = min(30, size_mb / 100)
                    score += size_score
            except:
                pass
            if len(languages) > 0:
                score += 15
            if 'Multi' in languages:
                score += 25
            ranked_streams.append({
                'stream': stream,
                'score': score,
                'quality_score': quality_score,
                'languages': languages,
                'index': i
            })
        ranked_streams.sort(key=lambda x: x['score'], reverse=True)
        return ranked_streams

    def _show_selector(self, files, display_title, force_manual=False, tmdb_id=None, season=None, episode=None, year=None, movie_title=None, show_title=None):
        """Show stream selection dialog and play selected"""
        if not files:
            return

        log(f"Showing stream selector for {display_title} with {len(files)} files")
        log(f"Selector using handle: {self.handle}")

        # Update language detection
        for file in files:
            if 'languages' not in file or not file['languages']:
                file['languages'] = self.detect_audio_languages(file.get('filename', ''))

        # Check autoplay settings
        autoplay = self.addon.getSetting('autoplay') == 'true'
        skip_popup = self.addon.getSetting('skip_popup') == 'true'

        # Auto-play best stream if enabled AND not forced manual
        if autoplay and skip_popup and not force_manual:
            ranked = self.rank_streams(files)
            if ranked:
                best = ranked[0]['stream']
                log(f"Auto-playing best stream: {best['filename']}")
                self._play_direct(
                    best['ident'],
                    display_title,
                    tmdb_id=tmdb_id,
                    season=season,
                    episode=episode,
                    year=year
                )
                return

        # Rank streams for display
        ranked = self.rank_streams(files)

        # Build dialog items
        items = []
        for i, ranked_item in enumerate(ranked):
            stream = ranked_item['stream']
            size_mb = 0
            try:
                size_mb = int(stream.get('size', 0)) / (1024 * 1024)
            except:
                pass
            size_str = ""
            if size_mb > 0:
                if size_mb > 1024:
                    size_str = f"{size_mb/1024:.1f} GB"
                else:
                    size_str = f"{size_mb:.0f} MB"
            languages = stream.get('languages', [])
            if languages:
                lang_str = "/".join(languages[:3])
                if len(languages) > 3:
                    lang_str += "+"
            else:
                lang_str = "Unknown"
            quality = stream.get('quality', 'SD')
            label = f"{i+1}. [B]{quality}[/B]"
            if lang_str != 'Unknown':
                label += f" ({lang_str})"
            if size_str:
                label += f" - {size_str}"
            if i == 0:
                label = f"[B][COLOR yellow]★ {label}[/COLOR][/B]"
            if '4K' in quality:
                label = f"[COLOR gold]{label}[/COLOR]"
            elif '1080p' in quality:
                label = f"[COLOR lime]{label}[/COLOR]"
            elif '720p' in quality:
                label = f"[COLOR cyan]{label}[/COLOR]"
            items.append((label, stream['ident']))

        # Show dialog
        dialog = xbmcgui.Dialog()
        selected = dialog.select(f"Select stream - {display_title}", [item[0] for item in items])

        if selected >= 0:
            stream_id = items[selected][1]
            log(f"User selected stream: {stream_id}")
            
            # CRITICAL FIX: Use plugin URL exactly like working playback!
            if tmdb_id and year and not season and movie_title:
                # Movie - use play_movie action
                safe_title = quote_plus(movie_title)
                plugin_url = f"plugin://plugin.video.mila/?action=play_movie&tmdb_id={tmdb_id}&title={safe_title}&year={year}"
                log(f"🎬 Using movie plugin URL: {plugin_url}")
                
                # Create list item with plugin URL
                li = xbmcgui.ListItem(label=display_title, path=plugin_url)
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.setResolvedUrl(self.handle, True, li)
                log(f"✅ Playback started via plugin URL with handle {self.handle}")
                
            elif tmdb_id and season and episode and show_title:
                # Episode - use play_episode action
                safe_title = quote_plus(show_title)
                plugin_url = f"plugin://plugin.video.mila/?action=play_episode&tmdb_id={tmdb_id}&show_title={safe_title}&season={season}&episode={episode}"
                log(f"📺 Using episode plugin URL: {plugin_url}")
                
                # Create list item with plugin URL
                li = xbmcgui.ListItem(label=display_title, path=plugin_url)
                li.setProperty('IsPlayable', 'true')
                xbmcplugin.setResolvedUrl(self.handle, True, li)
                log(f"✅ Playback started via plugin URL with handle {self.handle}")
            else:
                # Fallback to direct stream
                self._play_direct(stream_id, display_title, tmdb_id, season, episode, year)
        else:
            log("User cancelled stream selection")

    def _play_direct(self, ident, title, tmdb_id=None, season=None, episode=None, year=None):
        """Fallback: Play direct stream link"""
        log(f"Getting stream link for: {ident}")
        
        link = self.websharder.get_stream_link(ident)
        if not link:
            log("Failed to get stream link")
            poperror("Failed to get stream link")
            return

        token = self.websharder.token
        play_url = f"{link}|Cookie=wst={token}"
        log(f"Direct URL: {play_url[:100]}...")

        li = xbmcgui.ListItem(label=title, path=play_url)
        li.setProperty('IsPlayable', 'true')
        li.setMimeType('video/mp4')
        li.setContentLookup(False)

        # Try to get subtitles if enabled
        subtitles_enabled = self.addon.getSetting('subtitles_enabled') == 'true'
        if subtitles_enabled and tmdb_id:
            clean_title = title
            if year and str(year) in title:
                clean_title = title.replace(f"({year})", "").strip()
            if year and str(year) in clean_title:
                clean_title = clean_title.replace(str(year), "").strip()

            subtitle_file = self.opensubtitles.search_subtitles(
                tmdb_id=tmdb_id,
                title=clean_title,
                season=season,
                episode=episode,
                year=year
            )

            if subtitle_file and os.path.exists(subtitle_file):
                li.setSubtitles([subtitle_file])
                auto_subs = self.addon.getSetting('subtitles_auto') == 'true'
                if auto_subs:
                    li.setProperty('Subtitles', 'true')

        xbmcplugin.setResolvedUrl(self.handle, True, li)
        log(f"✅ Direct playback started with handle {self.handle}")
