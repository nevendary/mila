# -*- coding: utf-8 -*-
# Core addon class and router
import sys
import re  # CRITICAL FIX - ADD THIS!
import xbmcaddon
import xbmcplugin
from urllib.parse import parse_qsl

from lib.utils import log
from lib.tmdb import TMDB
from lib.websharder import WebSharder
from lib.gui import GUI
from lib.streaming import StreamSelector

class MILA:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.addon_id = self.addon.getAddonInfo('id')
        self.handle = int(sys.argv[1])
        self.url = sys.argv[0]

        # Initialize modules
        self.tmdb = TMDB(self.addon)
        self.websharder = WebSharder()
        self.gui = GUI(self)
        self.stream_selector = StreamSelector(self.addon, self.websharder)

    def get_url(self, **kwargs):
        """Create plugin URL"""
        from urllib.parse import urlencode
        return self.url + '?' + urlencode(kwargs)

    def router(self, paramstring):
        """Route to appropriate function"""
        params = dict(parse_qsl(paramstring))
        action = params.get('action', 'main_menu')

        log(f"Routing: {action}")

        if action == 'main_menu':
            self.main_menu()

        # TMDB Lists
        elif action == 'tmdb_list':
            list_type = params.get('list_type')
            list_name = params.get('list_name')
            self.show_tmdb_list(list_type, list_name)

        # Search
        elif action == 'search':
            self.search_menu()
        elif action == 'search_results':
            query = params.get('query', '')
            self.show_search_results(query)

        # TV Shows
        elif action == 'tv_popular':
            self.show_tmdb_list('popular_tv', self.gui._get_string('popular_tv'))
        elif action == 'tv_top_rated':
            self.show_tmdb_list('top_rated_tv', self.gui._get_string('top_rated_tv'))
        elif action == 'tv_show':
            tmdb_id = params.get('tmdb_id')
            self.show_tv_show_seasons(tmdb_id)
        elif action == 'tv_season':
            tmdb_id = params.get('tmdb_id')
            season = params.get('season')
            self.show_tv_season_episodes(tmdb_id, season)

        # Movies
        elif action == 'movie_popular':
            self.show_tmdb_list('popular_movies', self.gui._get_string('popular_movies'))
        elif action == 'movie_top_rated':
            self.show_tmdb_list('top_rated_movies', self.gui._get_string('top_rated_movies'))

        # Playback
        elif action == 'play_movie':
            tmdb_id = params.get('tmdb_id')
            title = params.get('title')
            year = params.get('year')
            self.stream_selector.play_movie(tmdb_id, title, year)

        elif action == 'play_episode':
            tmdb_id = params.get('tmdb_id')
            show_title = params.get('show_title')
            season = params.get('season')
            episode = params.get('episode')
            episode_title = params.get('episode_title', '')
            self.stream_selector.play_episode(tmdb_id, show_title, season, episode, episode_title)

        elif action == 'select_stream_manual':
            # For context menu manual selection - WITH HANDLE FIX!
            tmdb_id = params.get('tmdb_id')
            content_type = params.get('content_type')
            title = params.get('title')
            year = params.get('year', '')
            season = params.get('season', '')
            episode = params.get('episode', '')
            handle = params.get('handle')
            
            # DEBUG - log ALL params
            log(f"🔍 DEBUG - select_stream_manual ALL params: {dict(params)}")
            log(f"🔍 DEBUG - handle from URL: '{handle}'")
            
            # CRITICAL FIX: Strip curly braces and any non-digit characters from handle!
            if handle:
                # Remove curly braces and any other non-digit characters (keep minus sign for negative)
                clean_handle = re.sub(r'[^\d-]', '', handle)
                log(f"🔍 DEBUG - clean_handle: '{clean_handle}'")
                
                if clean_handle:
                    try:
                        self.stream_selector.handle = int(clean_handle)
                        log(f"✅ Manual select handle set to: {self.stream_selector.handle}")
                    except ValueError as e:
                        log(f"❌ Manual select handle conversion failed: {e}")
                        self.stream_selector.handle = self.handle
                        log(f"⚠️ Using fallback handle: {self.handle}")
                else:
                    self.stream_selector.handle = self.handle
                    log(f"⚠️ No valid handle found, using fallback: {self.handle}")
            else:
                self.stream_selector.handle = self.handle
                log(f"⚠️ No handle in URL, using fallback: {self.handle}")
            
            self.stream_selector.manual_select(tmdb_id, content_type, title, year, season, episode)

        elif action == 'clear_subtitles':
            from lib.opensubtitles import OpenSubtitles
            os = OpenSubtitles()
            os.clear_cache()
            xbmc.executebuiltin('Container.Refresh')

        else:
            self.main_menu()

    def main_menu(self):
        """Main menu with translations"""
        xbmcplugin.setPluginCategory(self.handle, 'MILA')
        xbmcplugin.setContent(self.handle, 'files')

        # Search
        self.gui.add_item(
            label=f'[B][COLOR yellow]{self.gui._get_string("search")}[/COLOR][/B]',
            url=self.get_url(action='search'),
            is_folder=True,
            art={'icon': 'DefaultSearch.png'}
        )

        # Movies section
        self.gui.add_item(
            label=f'[COLOR gold]{self.gui._get_string("popular_movies")}[/COLOR]',
            url=self.get_url(action='movie_popular'),
            is_folder=True,
            art={'icon': 'DefaultMovies.png'}
        )
        self.gui.add_item(
            label=f'[COLOR gold]{self.gui._get_string("top_rated_movies")}[/COLOR]',
            url=self.get_url(action='movie_top_rated'),
            is_folder=True,
            art={'icon': 'DefaultMovies.png'}
        )

        # TV Shows section
        self.gui.add_item(
            label=f'[COLOR cyan]{self.gui._get_string("popular_tv")}[/COLOR]',
            url=self.get_url(action='tv_popular'),
            is_folder=True,
            art={'icon': 'DefaultTVShows.png'}
        )
        self.gui.add_item(
            label=f'[COLOR cyan]{self.gui._get_string("top_rated_tv")}[/COLOR]',
            url=self.get_url(action='tv_top_rated'),
            is_folder=True,
            art={'icon': 'DefaultTVShows.png'}
        )

        xbmcplugin.endOfDirectory(self.handle)

    def search_menu(self):
        """Show search dialog with translations"""
        import xbmc
        keyboard = xbmc.Keyboard('', self.gui._get_string('search'))
        keyboard.doModal()

        if keyboard.isConfirmed():
            query = keyboard.getText()
            if query:
                self.show_search_results(query)

    def show_search_results(self, query):
        """Search TMDB and show results with translations"""
        xbmcplugin.setPluginCategory(self.handle, f'{self.gui._get_string("search")}: {query}')
        xbmcplugin.setContent(self.handle, 'files')

        # Search movies and TV shows
        movies = self.tmdb.search_movie(query)
        tv_shows = self.tmdb.search_tv(query)

        # Add header
        total = len(movies) + len(tv_shows)
        self.gui.add_item(
            label=f'[COLOR yellow]{self.gui._get_string("search_results", total)}[/COLOR]',
            url='',
            is_folder=False,
            art={'icon': 'DefaultFolder.png'}
        )

        # Add movies
        for movie in movies:
            self.gui.add_movie_item(movie, is_search_result=True)

        # Add TV shows
        for show in tv_shows:
            self.gui.add_tvshow_item(show, is_search_result=True)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tmdb_list(self, list_type, list_name):
        """Show TMDB list (popular, top rated) with translations"""
        xbmcplugin.setPluginCategory(self.handle, list_name)

        items = self.tmdb.get_list(list_type)

        if 'movie' in list_type:
            xbmcplugin.setContent(self.handle, 'movies')
            for item in items:
                self.gui.add_movie_item(item)
        else:
            xbmcplugin.setContent(self.handle, 'tvshows')
            for item in items:
                self.gui.add_tvshow_item(item)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tv_show_seasons(self, tmdb_id):
        """Show seasons of a TV show with translations"""
        show = self.tmdb.get_tv_details(tmdb_id)
        if not show:
            return

        show_name = show.get('name', 'TV Show')
        xbmcplugin.setPluginCategory(self.handle, show_name)
        xbmcplugin.setContent(self.handle, 'seasons')

        seasons = show.get('seasons', [])
        for season in seasons:
            season_num = season.get('season_number', 0)
            if season_num == 0:  # Skip specials
                continue

            self.gui.add_season_item(show, season)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tv_season_episodes(self, tmdb_id, season_num):
        """Show episodes of a season with translations"""
        show = self.tmdb.get_tv_details(tmdb_id)
        if not show:
            return

        season = self.tmdb.get_tv_season(tmdb_id, season_num)
        if not season:
            return

        show_title = show.get('name', '')
        xbmcplugin.setPluginCategory(
            self.handle,
            f'{show_title} - {self.gui._get_string("season")} {season_num}'
        )
        xbmcplugin.setContent(self.handle, 'episodes')

        episodes = season.get('episodes', [])
        for episode in episodes:
            self.gui.add_episode_item(show, season, episode)

        xbmcplugin.endOfDirectory(self.handle)

def run():
    """Entry point"""
    addon = MILA()
    if len(sys.argv) > 2:
        addon.router(sys.argv[2][1:])
    else:
        addon.router('')
