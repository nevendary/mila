# -*- coding: utf-8 -*-
# Core addon class and router - WITH SEARCH, WATCH HISTORY, AND 45+ TMDB DISCOVER LISTS
import sys
import re
import xbmc
import xbmcaddon
import xbmcplugin
from urllib.parse import parse_qsl

from lib.utils import log
from lib.tmdb import TMDB
from lib.websharder import WebSharder
from lib.gui import GUI
from lib.streaming import StreamSelector
from lib.history import HistoryManager

class MILA:
    def __init__(self):
        self.addon = xbmcaddon.Addon()
        self.addon_id = self.addon.getAddonInfo('id')
        self.handle = int(sys.argv[1])
        self.url = sys.argv[0]

        # Initialize modules
        self.tmdb = TMDB(self.addon)
        self.websharder = WebSharder()
        self.gui = GUI(self)
        self.stream_selector = StreamSelector(self.addon, self.websharder)
        self.history = HistoryManager()

    def get_url(self, **kwargs):
        """Create plugin URL"""
        from urllib.parse import urlencode
        return self.url + '?' + urlencode(kwargs)

    def router(self, paramstring):
        """Route to appropriate function"""
        params = dict(parse_qsl(paramstring))
        action = params.get('action', 'main_menu')

        log(f"Routing: {action}")

        # ===== MAIN MENU =====
        if action == 'main_menu':
            self.main_menu()

        # ===== DISCOVER MENUS =====
        elif action == 'discover_menu':
            self.discover_menu()
        elif action == 'discover_trending':
            self.show_discover_list('trending_week', self.gui._get_string('trending_week'))
        elif action == 'discover_trending_day':
            self.show_discover_list('trending_day', self.gui._get_string('trending_day'))
        elif action == 'discover_now_playing':
            self.show_discover_list('now_playing', self.gui._get_string('now_playing'))
        elif action == 'discover_upcoming':
            self.show_discover_list('upcoming', self.gui._get_string('upcoming'))

        # ===== GENRE MENUS =====
        elif action == 'genres_menu':
            self.genres_menu()
        elif action == 'genre_action':
            self.show_discover_list('action_movies', self.gui._get_string('action'))
        elif action == 'genre_adventure':
            self.show_discover_list('adventure_movies', self.gui._get_string('adventure'))
        elif action == 'genre_action_adventure':
            self.show_discover_list('action_adventure', self.gui._get_string('action_adventure'))
        elif action == 'genre_comedy':
            self.show_discover_list('comedy_movies', self.gui._get_string('comedy'))
        elif action == 'genre_drama':
            self.show_discover_list('drama_movies', self.gui._get_string('drama'))
        elif action == 'genre_comedy_drama':
            self.show_discover_list('comedy_drama', self.gui._get_string('comedy_drama'))
        elif action == 'genre_thriller':
            self.show_discover_list('thriller_movies', self.gui._get_string('thriller'))
        elif action == 'genre_horror':
            self.show_discover_list('horror_movies', self.gui._get_string('horror'))
        elif action == 'genre_thriller_horror':
            self.show_discover_list('thriller_horror', self.gui._get_string('thriller_horror'))
        elif action == 'genre_scifi':
            self.show_discover_list('sci_fi_movies', self.gui._get_string('sci_fi'))
        elif action == 'genre_fantasy':
            self.show_discover_list('fantasy_movies', self.gui._get_string('fantasy'))
        elif action == 'genre_scifi_fantasy':
            self.show_discover_list('sci_fi_fantasy', self.gui._get_string('sci_fi_fantasy'))
        elif action == 'genre_romance':
            self.show_discover_list('romance_movies', self.gui._get_string('romance'))
        elif action == 'genre_family':
            self.show_discover_list('family_movies', self.gui._get_string('family'))
        elif action == 'genre_animation':
            self.show_discover_list('animation_movies', self.gui._get_string('animation'))
        elif action == 'genre_family_animation':
            self.show_discover_list('family_animation', self.gui._get_string('family_animation'))
        elif action == 'genre_documentary':
            self.show_discover_list('documentary_movies', self.gui._get_string('documentary'))
        elif action == 'genre_war':
            self.show_discover_list('war_movies', self.gui._get_string('war'))
        elif action == 'genre_history':
            self.show_discover_list('history_movies', self.gui._get_string('history'))
        elif action == 'genre_war_history':
            self.show_discover_list('war_history', self.gui._get_string('war_history'))
        elif action == 'genre_crime':
            self.show_discover_list('crime_movies', self.gui._get_string('crime'))
        elif action == 'genre_mystery':
            self.show_discover_list('mystery_movies', self.gui._get_string('mystery'))

        # ===== YUGOSLAV / EX-YU MENUS =====
        elif action == 'yugoslav_menu':
            self.yugoslav_menu()
        elif action == 'yugoslav_movies_all':
            self.show_discover_list('ex_yu_movies_all', self.gui._get_string('yugoslav_movies_all'))
        elif action == 'yugoslav_tv_all':
            self.show_discover_list('ex_yu_tv_all', self.gui._get_string('yugoslav_tv_all'))
        elif action == 'yugoslav_classics':
            self.show_discover_list('yugoslav_classics', self.gui._get_string('yugoslav_classics'))
        elif action == 'yugoslav_tv_classics':
            self.show_discover_list('yugoslav_tv_classics', self.gui._get_string('yugoslav_tv_classics'))
        elif action == 'yugoslav_westerns':
            self.show_discover_list('yugoslav_westerns', self.gui._get_string('yugoslav_westerns'))
        elif action == 'serbian_movies':
            self.show_discover_list('serbian_movies', self.gui._get_string('serbian_movies'))
        elif action == 'serbian_tv':
            self.show_discover_list('serbian_tv', self.gui._get_string('serbian_tv'))
        elif action == 'croatian_movies':
            self.show_discover_list('croatian_movies', self.gui._get_string('croatian_movies'))
        elif action == 'croatian_tv':
            self.show_discover_list('croatian_tv', self.gui._get_string('croatian_tv'))
        elif action == 'bosnian_movies':
            self.show_discover_list('bosnian_movies', self.gui._get_string('bosnian_movies'))
        elif action == 'bosnian_tv':
            self.show_discover_list('bosnian_tv', self.gui._get_string('bosnian_tv'))
        elif action == 'montenegrin_movies':
            self.show_discover_list('montenegrin_movies', self.gui._get_string('montenegrin_movies'))
        elif action == 'montenegrin_tv':
            self.show_discover_list('montenegrin_tv', self.gui._get_string('montenegrin_tv'))
        elif action == 'regional_recent_movies':
            self.show_discover_list('regional_recent_movies', self.gui._get_string('regional_recent_movies'))
        elif action == 'regional_recent_tv':
            self.show_discover_list('regional_recent_tv', self.gui._get_string('regional_recent_tv'))
        elif action == 'partisan_films':
            self.show_discover_list('partisan_films', self.gui._get_string('partisan_films'))
        elif action == 'pula_film_festival':
            self.show_discover_list('pula_film_festival', self.gui._get_string('pula_film_festival'))
        elif action == 'sarajevo_film_festival':
            self.show_discover_list('sarajevo_film_festival', self.gui._get_string('sarajevo_film_festival'))

        # ===== CZECH & REGIONAL MENUS =====
        elif action == 'czech_menu':
            self.czech_menu()
        elif action == 'czech_movies':
            self.show_discover_list('czech_movies', self.gui._get_string('czech_movies'))
        elif action == 'czech_recent':
            self.show_discover_list('czech_recent', self.gui._get_string('czech_recent'))
        elif action == 'czechoslovak_classics':
            self.show_discover_list('czechoslovak_classics', self.gui._get_string('czechoslovak_classics'))
        elif action == 'slovak_movies':
            self.show_discover_list('slovak_movies', self.gui._get_string('slovak_movies'))
        elif action == 'czech_tv':
            self.show_discover_list('czech_tv', self.gui._get_string('czech_movies') + ' TV')
        elif action == 'slovak_tv':
            self.show_discover_list('slovak_tv', self.gui._get_string('slovak_movies') + ' TV')

        # ===== STUDIO MENUS =====
        elif action == 'studios_menu':
            self.studios_menu()
        elif action == 'studio_marvel':
            self.show_discover_list('marvel_movies', self.gui._get_string('marvel'))
        elif action == 'studio_dc':
            self.show_discover_list('dc_movies', self.gui._get_string('dc'))
        elif action == 'studio_disney':
            self.show_discover_list('disney_movies', self.gui._get_string('disney'))
        elif action == 'studio_netflix':
            self.show_discover_list('netflix_movies', self.gui._get_string('netflix'))
        elif action == 'studio_hbo':
            self.show_discover_list('hbo_movies', self.gui._get_string('hbo'))
        elif action == 'studio_amazon':
            self.show_discover_list('amazon_movies', self.gui._get_string('amazon'))
        elif action == 'studio_apple':
            self.show_discover_list('apple_movies', self.gui._get_string('apple'))
        elif action == 'studio_paramount':
            self.show_discover_list('paramount_movies', self.gui._get_string('paramount'))
        elif action == 'studio_universal':
            self.show_discover_list('universal_movies', self.gui._get_string('universal'))
        elif action == 'studio_warner':
            self.show_discover_list('warner_movies', self.gui._get_string('warner'))
        elif action == 'studio_sony':
            self.show_discover_list('sony_movies', self.gui._get_string('sony'))

        # ===== DECADE MENUS =====
        elif action == 'decades_menu':
            self.decades_menu()
        elif action == 'decade_80s':
            self.show_discover_list('_80s_movies', self.gui._get_string('decade_80s'))
        elif action == 'decade_90s':
            self.show_discover_list('_90s_movies', self.gui._get_string('decade_90s'))
        elif action == 'decade_00s':
            self.show_discover_list('_00s_movies', self.gui._get_string('decade_00s'))
        elif action == 'decade_2010s':
            self.show_discover_list('_2010s_movies', self.gui._get_string('decade_2010s'))
        elif action == 'decade_2020s':
            self.show_discover_list('_2020s_movies', self.gui._get_string('decade_2020s'))

        # ===== SMART MIXES =====
        elif action == 'smart_mixes_menu':
            self.smart_mixes_menu()
        elif action == 'smart_cult_classics':
            self.show_discover_list('cult_classics', self.gui._get_string('cult_classics'))
        elif action == 'smart_feel_good':
            self.show_discover_list('feel_good_movies', self.gui._get_string('feel_good'))
        elif action == 'smart_date_night':
            self.show_discover_list('date_night_movies', self.gui._get_string('date_night'))
        elif action == 'smart_weekend_binge':
            self.show_discover_list('weekend_binge', self.gui._get_string('weekend_binge'))

        # ===== RECENT RELEASES =====
        elif action == 'recent_menu':
            self.recent_menu()
        elif action == 'recent_month':
            self.show_discover_list('this_month', self.gui._get_string('this_month'))
        elif action == 'recent_3months':
            self.show_discover_list('last_3_months', self.gui._get_string('last_3_months'))
        elif action == 'recent_year':
            self.show_discover_list('this_year', self.gui._get_string('this_year'))

        # ===== HISTORY ACTIONS =====
        elif action == 'search_history':
            self.show_search_history()
        elif action == 'watch_history':
            self.show_watch_history()
        elif action == 'clear_search_history':
            self.history.clear_search_history()
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'clear_watch_history':
            self.history.clear_watch_history()
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'remove_watch_item':
            index = params.get('index')
            if index:
                self.history.remove_from_watch_history(int(index))
        elif action == 'remove_search_item':
            query = params.get('query')
            if query:
                self.history.remove_search_item(query)
                xbmc.executebuiltin('Container.Refresh')
        elif action == 'search_from_history':
            query = params.get('query')
            if query:
                self.show_search_results(query)

        # ===== SEARCH =====
        elif action == 'search':
            self.search_menu()
        elif action == 'search_results':
            query = params.get('query', '')
            self.show_search_results(query)

        # ===== TV SHOWS - DIRECT TMDB CALLS, NO WEBSHARE =====
        elif action == 'tv_popular':
            self.show_tv_popular()
        elif action == 'tv_top_rated':
            self.show_tv_top_rated()
        elif action == 'tv_show':
            tmdb_id = params.get('tmdb_id')
            self.show_tv_show_seasons(tmdb_id)
        elif action == 'tv_season':
            tmdb_id = params.get('tmdb_id')
            season = params.get('season')
            self.show_tv_season_episodes(tmdb_id, season)

        # ===== MOVIES - DIRECT TMDB CALLS, NO WEBSHARE =====
        elif action == 'movie_popular':
            self.show_movie_popular()
        elif action == 'movie_top_rated':
            self.show_movie_top_rated()

        # ===== PLAYBACK - ONLY THESE USE WEBSHARE =====
        elif action == 'play_movie':
            tmdb_id = params.get('tmdb_id')
            title = params.get('title')
            year = params.get('year')
            stream_id = params.get('stream_id')

            movie_details = self.tmdb.get_movie_details(tmdb_id)

            self.stream_selector.play_movie(
                tmdb_id=tmdb_id,
                title=title,
                year=year,
                stream_id=stream_id,
                handle=self.handle,
                movie_details=movie_details
            )

        elif action == 'play_episode':
            tmdb_id = params.get('tmdb_id')
            show_title = params.get('show_title')
            season = params.get('season')
            episode = params.get('episode')
            episode_title = params.get('episode_title', '')
            stream_id = params.get('stream_id')

            episode_details = self.tmdb.get_episode_details(tmdb_id, season, episode)
            show_details = self.tmdb.get_tv_details(tmdb_id)

            self.stream_selector.play_episode(
                tmdb_id=tmdb_id,
                show_title=show_title,
                season=season,
                episode=episode,
                episode_title=episode_title,
                stream_id=stream_id,
                handle=self.handle,
                episode_details=episode_details,
                show_details=show_details
            )

        elif action == 'select_stream_manual':
            tmdb_id = params.get('tmdb_id')
            content_type = params.get('content_type')
            title = params.get('title')
            year = params.get('year', '')
            season = params.get('season', '')
            episode = params.get('episode', '')
            handle = params.get('handle')

            clean_handle = None
            if handle:
                clean_handle = re.sub(r'[^\d-]', '', handle)

            self.stream_selector.manual_select(
                tmdb_id=tmdb_id,
                content_type=content_type,
                title=title,
                year=year,
                season=season,
                episode=episode,
                handle=clean_handle
            )

        elif action == 'clear_subtitles':
            from lib.opensubtitles import OpenSubtitles
            os = OpenSubtitles()
            os.clear_cache()
            xbmc.executebuiltin('Container.Refresh')

        else:
            self.main_menu()

    def main_menu(self):
        """Main menu - NO EMOJIS, POPULAR/TOP RATED AT TOP"""
        xbmcplugin.setPluginCategory(self.handle, 'MILA')
        xbmcplugin.setContent(self.handle, 'files')

        # SEARCH & HISTORY
        self.gui.add_item(
            label=f'[B][COLOR yellow]{self.gui._get_string("search")}[/COLOR][/B]',
            url=self.get_url(action='search'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('search_history'),
            url=self.get_url(action='search_history'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('watch_history'),
            url=self.get_url(action='watch_history'),
            is_folder=True
        )

        # POPULAR & TOP RATED - DIRECT TMDB CALLS, NO WEBSHARE
        self.gui.add_item(
            label=f'[B]{self.gui._get_string("popular_movies")}[/B]',
            url=self.get_url(action='movie_popular'),
            is_folder=True
        )
        self.gui.add_item(
            label=f'[B]{self.gui._get_string("top_rated_movies")}[/B]',
            url=self.get_url(action='movie_top_rated'),
            is_folder=True
        )
        self.gui.add_item(
            label=f'[B]{self.gui._get_string("popular_tv")}[/B]',
            url=self.get_url(action='tv_popular'),
            is_folder=True
        )
        self.gui.add_item(
            label=f'[B]{self.gui._get_string("top_rated_tv")}[/B]',
            url=self.get_url(action='tv_top_rated'),
            is_folder=True
        )

        # DISCOVER SECTIONS
        self.gui.add_item(
            label=self.gui._get_string('trending_now'),
            url=self.get_url(action='discover_menu'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('genres'),
            url=self.get_url(action='genres_menu'),
            is_folder=True
        )
        
        # YUGOSLAV MENU - ADDED HERE
        self.gui.add_item(
            label=self.gui._get_string('yugoslav_region'),
            url=self.get_url(action='yugoslav_menu'),
            is_folder=True
        )
        
        self.gui.add_item(
            label=self.gui._get_string('czech_slovak'),
            url=self.get_url(action='czech_menu'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('studios'),
            url=self.get_url(action='studios_menu'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('decades'),
            url=self.get_url(action='decades_menu'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('smart_mixes'),
            url=self.get_url(action='smart_mixes_menu'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('recent_releases'),
            url=self.get_url(action='recent_menu'),
            is_folder=True
        )

        xbmcplugin.endOfDirectory(self.handle)

    # ===== DIRECT TMDB LIST METHODS - NO WEBSHARE =====

    def show_movie_popular(self):
        """Show popular movies directly from TMDB"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('popular_movies'))
        xbmcplugin.setContent(self.handle, 'movies')

        try:
            items = self.tmdb.get_popular_movies()
            log(f"Got {len(items)} popular movies from TMDB")
        except Exception as e:
            log(f"Error getting popular movies: {str(e)}")
            items = []

        if not items:
            self.gui.add_item(
                label='[COLOR grey]No movies found[/COLOR]',
                url='',
                is_folder=False
            )
        else:
            for item in items:
                self.gui.add_movie_item(item)

        xbmcplugin.endOfDirectory(self.handle)

    def show_movie_top_rated(self):
        """Show top rated movies directly from TMDB"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('top_rated_movies'))
        xbmcplugin.setContent(self.handle, 'movies')

        try:
            items = self.tmdb.get_top_rated_movies()
            log(f"Got {len(items)} top rated movies from TMDB")
        except Exception as e:
            log(f"Error getting top rated movies: {str(e)}")
            items = []

        if not items:
            self.gui.add_item(
                label='[COLOR grey]No movies found[/COLOR]',
                url='',
                is_folder=False
            )
        else:
            for item in items:
                self.gui.add_movie_item(item)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tv_popular(self):
        """Show popular TV shows directly from TMDB"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('popular_tv'))
        xbmcplugin.setContent(self.handle, 'tvshows')

        try:
            items = self.tmdb.get_popular_tv()
            log(f"Got {len(items)} popular TV shows from TMDB")
        except Exception as e:
            log(f"Error getting popular TV: {str(e)}")
            items = []

        if not items:
            self.gui.add_item(
                label='[COLOR grey]No TV shows found[/COLOR]',
                url='',
                is_folder=False
            )
        else:
            for item in items:
                self.gui.add_tvshow_item(item)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tv_top_rated(self):
        """Show top rated TV shows directly from TMDB"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('top_rated_tv'))
        xbmcplugin.setContent(self.handle, 'tvshows')

        try:
            items = self.tmdb.get_top_rated_tv()
            log(f"Got {len(items)} top rated TV shows from TMDB")
        except Exception as e:
            log(f"Error getting top rated TV: {str(e)}")
            items = []

        if not items:
            self.gui.add_item(
                label='[COLOR grey]No TV shows found[/COLOR]',
                url='',
                is_folder=False
            )
        else:
            for item in items:
                self.gui.add_tvshow_item(item)

        xbmcplugin.endOfDirectory(self.handle)

    # ===== DISCOVER METHODS =====

    def show_discover_list(self, discover_method, list_name):
        """Show results from TMDB discover methods"""
        xbmcplugin.setPluginCategory(self.handle, list_name)
        
        # Set content type based on method name
        if '_tv' in discover_method or 'tv_all' in discover_method or 'tv_classics' in discover_method or 'serbian_tv' in discover_method or 'croatian_tv' in discover_method or 'bosnian_tv' in discover_method or 'montenegrin_tv' in discover_method or 'regional_recent_tv' in discover_method:
            xbmcplugin.setContent(self.handle, 'tvshows')
        else:
            xbmcplugin.setContent(self.handle, 'movies')

        try:
            discover_func = getattr(self.tmdb, discover_method)
            items = discover_func()
            log(f"Got {len(items)} from {discover_method}")
        except Exception as e:
            log(f"Error in discover {discover_method}: {str(e)}")
            items = []

        if not items:
            self.gui.add_item(
                label='[COLOR grey]No items found[/COLOR]',
                url='',
                is_folder=False
            )
        else:
            for item in items:
                if '_tv' in discover_method or 'tv_all' in discover_method or 'tv_classics' in discover_method or 'serbian_tv' in discover_method or 'croatian_tv' in discover_method or 'bosnian_tv' in discover_method or 'montenegrin_tv' in discover_method or 'regional_recent_tv' in discover_method:
                    self.gui.add_tvshow_item(item)
                else:
                    self.gui.add_movie_item(item)

        xbmcplugin.endOfDirectory(self.handle)

    # ===== MENU STRUCTURE METHODS =====

    def discover_menu(self):
        """Trending and Now Playing menu"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('trending_now'))
        xbmcplugin.setContent(self.handle, 'files')

        self.gui.add_item(
            label=self.gui._get_string('trending_week'),
            url=self.get_url(action='discover_trending'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('trending_day'),
            url=self.get_url(action='discover_trending_day'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('now_playing'),
            url=self.get_url(action='discover_now_playing'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('upcoming'),
            url=self.get_url(action='discover_upcoming'),
            is_folder=True
        )

        xbmcplugin.endOfDirectory(self.handle)

    def genres_menu(self):
        """All genre categories"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('genres'))
        xbmcplugin.setContent(self.handle, 'files')

        self.gui.add_item(label=self.gui._get_string('action'), url=self.get_url(action='genre_action'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('adventure'), url=self.get_url(action='genre_adventure'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('action_adventure'), url=self.get_url(action='genre_action_adventure'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('comedy'), url=self.get_url(action='genre_comedy'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('drama'), url=self.get_url(action='genre_drama'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('comedy_drama'), url=self.get_url(action='genre_comedy_drama'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('thriller'), url=self.get_url(action='genre_thriller'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('horror'), url=self.get_url(action='genre_horror'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('thriller_horror'), url=self.get_url(action='genre_thriller_horror'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('sci_fi'), url=self.get_url(action='genre_scifi'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('fantasy'), url=self.get_url(action='genre_fantasy'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('sci_fi_fantasy'), url=self.get_url(action='genre_scifi_fantasy'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('romance'), url=self.get_url(action='genre_romance'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('family'), url=self.get_url(action='genre_family'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('animation'), url=self.get_url(action='genre_animation'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('family_animation'), url=self.get_url(action='genre_family_animation'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('documentary'), url=self.get_url(action='genre_documentary'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('war'), url=self.get_url(action='genre_war'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('history'), url=self.get_url(action='genre_history'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('war_history'), url=self.get_url(action='genre_war_history'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('crime'), url=self.get_url(action='genre_crime'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('mystery'), url=self.get_url(action='genre_mystery'), is_folder=True)

        xbmcplugin.endOfDirectory(self.handle)

    # ===== YUGOSLAV MENU - LIKE EVERY OTHER FUCKING MENU =====
    def yugoslav_menu(self):
        """Yugoslav and Ex-YU regional content"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('yugoslav_region'))
        xbmcplugin.setContent(self.handle, 'files')

        # ALL REGION COMBINED
        self.gui.add_item(
            label=f'[B]{self.gui._get_string("yugoslav_movies_all")}[/B]',
            url=self.get_url(action='yugoslav_movies_all'),
            is_folder=True
        )
        self.gui.add_item(
            label=f'[B]{self.gui._get_string("yugoslav_tv_all")}[/B]',
            url=self.get_url(action='yugoslav_tv_all'),
            is_folder=True
        )
        self.gui.add_item(
            label='---',
            url='',
            is_folder=False
        )

        # BY COUNTRY
        self.gui.add_item(
            label=self.gui._get_string('serbian_movies'),
            url=self.get_url(action='serbian_movies'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('serbian_tv'),
            url=self.get_url(action='serbian_tv'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('croatian_movies'),
            url=self.get_url(action='croatian_movies'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('croatian_tv'),
            url=self.get_url(action='croatian_tv'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('bosnian_movies'),
            url=self.get_url(action='bosnian_movies'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('bosnian_tv'),
            url=self.get_url(action='bosnian_tv'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('montenegrin_movies'),
            url=self.get_url(action='montenegrin_movies'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('montenegrin_tv'),
            url=self.get_url(action='montenegrin_tv'),
            is_folder=True
        )
        self.gui.add_item(
            label='---',
            url='',
            is_folder=False
        )

        # CLASSICS & SPECIAL COLLECTIONS
        self.gui.add_item(
            label=self.gui._get_string('yugoslav_classics'),
            url=self.get_url(action='yugoslav_classics'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('yugoslav_tv_classics'),
            url=self.get_url(action='yugoslav_tv_classics'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('yugoslav_westerns'),
            url=self.get_url(action='yugoslav_westerns'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('partisan_films'),
            url=self.get_url(action='partisan_films'),
            is_folder=True
        )
        self.gui.add_item(
            label='---',
            url='',
            is_folder=False
        )

        # RECENT & POPULAR
        self.gui.add_item(
            label=self.gui._get_string('regional_recent_movies'),
            url=self.get_url(action='regional_recent_movies'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('regional_recent_tv'),
            url=self.get_url(action='regional_recent_tv'),
            is_folder=True
        )

        # FESTIVALS
        self.gui.add_item(
            label=self.gui._get_string('pula_film_festival'),
            url=self.get_url(action='pula_film_festival'),
            is_folder=True
        )
        self.gui.add_item(
            label=self.gui._get_string('sarajevo_film_festival'),
            url=self.get_url(action='sarajevo_film_festival'),
            is_folder=True
        )

        xbmcplugin.endOfDirectory(self.handle)

    def czech_menu(self):
        """Czech and Slovak content"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('czech_slovak'))
        xbmcplugin.setContent(self.handle, 'files')

        self.gui.add_item(label=self.gui._get_string('czech_movies'), url=self.get_url(action='czech_movies'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('czech_movies') + ' TV', url=self.get_url(action='czech_tv'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('czech_recent'), url=self.get_url(action='czech_recent'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('czechoslovak_classics'), url=self.get_url(action='czechoslovak_classics'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('slovak_movies'), url=self.get_url(action='slovak_movies'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('slovak_movies') + ' TV', url=self.get_url(action='slovak_tv'), is_folder=True)

        xbmcplugin.endOfDirectory(self.handle)

    def studios_menu(self):
        """Studio/production company collections"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('studios'))
        xbmcplugin.setContent(self.handle, 'files')

        self.gui.add_item(label=self.gui._get_string('marvel'), url=self.get_url(action='studio_marvel'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('dc'), url=self.get_url(action='studio_dc'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('disney'), url=self.get_url(action='studio_disney'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('netflix'), url=self.get_url(action='studio_netflix'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('hbo'), url=self.get_url(action='studio_hbo'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('amazon'), url=self.get_url(action='studio_amazon'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('apple'), url=self.get_url(action='studio_apple'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('paramount'), url=self.get_url(action='studio_paramount'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('universal'), url=self.get_url(action='studio_universal'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('warner'), url=self.get_url(action='studio_warner'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('sony'), url=self.get_url(action='studio_sony'), is_folder=True)

        xbmcplugin.endOfDirectory(self.handle)

    def decades_menu(self):
        """Movies by decade"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('decades'))
        xbmcplugin.setContent(self.handle, 'files')

        self.gui.add_item(label=self.gui._get_string('decade_80s'), url=self.get_url(action='decade_80s'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('decade_90s'), url=self.get_url(action='decade_90s'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('decade_00s'), url=self.get_url(action='decade_00s'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('decade_2010s'), url=self.get_url(action='decade_2010s'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('decade_2020s'), url=self.get_url(action='decade_2020s'), is_folder=True)

        xbmcplugin.endOfDirectory(self.handle)

    def smart_mixes_menu(self):
        """Curated collections"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('smart_mixes'))
        xbmcplugin.setContent(self.handle, 'files')

        self.gui.add_item(label=self.gui._get_string('cult_classics'), url=self.get_url(action='smart_cult_classics'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('feel_good'), url=self.get_url(action='smart_feel_good'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('date_night'), url=self.get_url(action='smart_date_night'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('weekend_binge'), url=self.get_url(action='smart_weekend_binge'), is_folder=True)

        xbmcplugin.endOfDirectory(self.handle)

    def recent_menu(self):
        """Recent releases"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('recent_releases'))
        xbmcplugin.setContent(self.handle, 'files')

        self.gui.add_item(label=self.gui._get_string('this_month'), url=self.get_url(action='recent_month'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('last_3_months'), url=self.get_url(action='recent_3months'), is_folder=True)
        self.gui.add_item(label=self.gui._get_string('this_year'), url=self.get_url(action='recent_year'), is_folder=True)

        xbmcplugin.endOfDirectory(self.handle)

    # ===== TV SHOW METHODS =====

    def show_tv_show_seasons(self, tmdb_id):
        """Show seasons of a TV show"""
        show = self.tmdb.get_tv_details(tmdb_id)
        if not show:
            return

        show_name = show.get('name', 'TV Show')
        xbmcplugin.setPluginCategory(self.handle, show_name)
        xbmcplugin.setContent(self.handle, 'seasons')

        seasons = show.get('seasons', [])
        for season in seasons:
            season_num = season.get('season_number', 0)
            if season_num == 0:
                continue

            self.gui.add_season_item(show, season)

        xbmcplugin.endOfDirectory(self.handle)

    def show_tv_season_episodes(self, tmdb_id, season_num):
        """Show episodes of a season"""
        show = self.tmdb.get_tv_details(tmdb_id)
        if not show:
            return

        season = self.tmdb.get_tv_season(tmdb_id, season_num)
        if not season:
            return

        show_title = show.get('name', '')
        xbmcplugin.setPluginCategory(
            self.handle,
            f'{show_title} - {self.gui._get_string("season")} {season_num}'
        )
        xbmcplugin.setContent(self.handle, 'episodes')

        episodes = season.get('episodes', [])
        for episode in episodes:
            self.gui.add_episode_item(show, season, episode)

        xbmcplugin.endOfDirectory(self.handle)

    # ===== HISTORY METHODS =====

    def show_search_history(self):
        """Show search history"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('search_history'))
        xbmcplugin.setContent(self.handle, 'files')

        history = self.history.get_search_history()

        if not history:
            self.gui.add_item(
                label=f'[COLOR grey]{self.gui._get_string("no_search_history")}[/COLOR]',
                url='',
                is_folder=False
            )
        else:
            for item in history:
                query = item.get('query', '')

                context_menu = [
                    (
                        self.gui._get_string('remove_from_history'),
                        f'RunPlugin({self.get_url(action="remove_search_item", query=query)})'
                    ),
                    (
                        self.gui._get_string('clear_all'),
                        f'RunPlugin({self.get_url(action="clear_search_history")})'
                    )
                ]

                self.gui.add_item(
                    label=f'[COLOR white]{query}[/COLOR]',
                    url=self.get_url(action='search_results', query=query),
                    is_folder=True,
                    context_menu=context_menu
                )

        if history:
            self.gui.add_item(
                label=f'[COLOR red]{self.gui._get_string("clear_all")}[/COLOR]',
                url=self.get_url(action='clear_search_history'),
                is_folder=False
            )

        xbmcplugin.endOfDirectory(self.handle)

    def show_watch_history(self):
        """Show watch history"""
        xbmcplugin.setPluginCategory(self.handle, self.gui._get_string('watch_history'))
        xbmcplugin.setContent(self.handle, 'videos')

        history = self.history.get_watch_history()

        if not history:
            self.gui.add_item(
                label=f'[COLOR grey]{self.gui._get_string("no_watch_history")}[/COLOR]',
                url='',
                is_folder=False
            )
        else:
            for index, item in enumerate(history):
                item_type = item.get('type', '')

                if item_type == 'movie':
                    title = item.get('title', 'Unknown')
                    year = item.get('year', '')
                    tmdb_id = item.get('tmdb_id')

                    label = f'[COLOR gold]{title}[/COLOR]'
                    if year:
                        label += f' [COLOR grey]({year})[/COLOR]'

                    url = self.get_url(
                        action='play_movie',
                        tmdb_id=tmdb_id,
                        title=title,
                        year=year
                    )

                    art = {'icon': 'DefaultMovies.png'}
                    if item.get('poster'):
                        art['thumb'] = f"https://image.tmdb.org/t/p/w185{item['poster']}"

                else:
                    show_title = item.get('show_title', 'Unknown')
                    season = item.get('season', 0)
                    episode = item.get('episode', 0)
                    episode_title = item.get('title', '')
                    tmdb_id = item.get('tmdb_id')

                    label = f'[COLOR cyan]{show_title}[/COLOR] [COLOR grey]- S{int(season):02d}E{int(episode):02d}[/COLOR]'
                    if episode_title and episode_title != f'S{season}E{episode}':
                        label += f' [COLOR white]- {episode_title}[/COLOR]'

                    url = self.get_url(
                        action='play_episode',
                        tmdb_id=tmdb_id,
                        show_title=show_title,
                        season=season,
                        episode=episode,
                        episode_title=episode_title
                    )

                    art = {'icon': 'DefaultTVShows.png'}
                    if item.get('poster'):
                        art['thumb'] = f"https://image.tmdb.org/t/p/w185{item['poster']}"

                context_menu = [
                    (
                        self.gui._get_string('remove_from_history'),
                        f'RunPlugin({self.get_url(action="remove_watch_item", index=index)})'
                    )
                ]

                self.gui.add_item(
                    label=label,
                    url=url,
                    is_folder=False,
                    art=art,
                    context_menu=context_menu
                )

            self.gui.add_item(
                label=f'[COLOR red]{self.gui._get_string("clear_all")}[/COLOR]',
                url=self.get_url(action='clear_watch_history'),
                is_folder=False
            )

        xbmcplugin.endOfDirectory(self.handle)

    def search_menu(self):
        """Show search dialog and save to history"""
        keyboard = xbmc.Keyboard('', self.gui._get_string('search'))
        keyboard.doModal()

        if keyboard.isConfirmed():
            query = keyboard.getText()
            if query:
                self.history.add_search(query)
                self.show_search_results(query)

    def show_search_results(self, query):
        """Search TMDB and show results"""
        xbmcplugin.setPluginCategory(self.handle, f'{self.gui._get_string("search")}: {query}')
        xbmcplugin.setContent(self.handle, 'files')

        movies = self.tmdb.search_movie(query)
        tv_shows = self.tmdb.search_tv(query)

        total = len(movies) + len(tv_shows)

        self.gui.add_item(
            label=f'[COLOR yellow]{self.gui._get_string("search_results").format(total)}[/COLOR]',
            url='',
            is_folder=False
        )

        for movie in movies:
            self.gui.add_movie_item(movie, is_search_result=True)

        for show in tv_shows:
            self.gui.add_tvshow_item(show, is_search_result=True)

        xbmcplugin.endOfDirectory(self.handle)

def run():
    """Entry point"""
    addon = MILA()
    if len(sys.argv) > 2:
        addon.router(sys.argv[2][1:])
    else:
        addon.router('')
