# -*- coding: utf-8 -*-
# Legacy support - redirects to new structure
from lib.addon import run

if __name__ == '__main__':
    run()
