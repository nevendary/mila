# -*- coding: utf-8 -*-
# Entry point
from lib.addon import run
run()
