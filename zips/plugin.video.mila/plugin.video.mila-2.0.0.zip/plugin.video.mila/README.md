# plugin.video.yawsp
Yet Another WebShare Plugin

Kodi plugin pre webshare.cz

Plugin neposkytuje žiaden obsah, je to len simulácia prehliadača verejne dostupnej web stránky. Nie som zodpovedný za obsah, ktorý táto stránka poskytuje.